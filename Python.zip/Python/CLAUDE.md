# CLAUDE.md — System Design Simulator

Guidance for AI agents (Claude, Copilot, etc.) working in this repository.

## What this project is

An interactive, browser-based **system design simulator** inspired by
[paperdraw.dev](https://paperdraw.dev). Users visually compose a distributed-system
architecture on a canvas, run a **discrete-event / queueing-network simulation** driven by
adjustable traffic, inject **chaos** (failures), and watch **live, computed metrics** —
throughput, latency, success rate, bandwidth, per-node load, and single-point-of-failure
detection.

## Why it exists (purpose)

- **Learning & interview prep:** let engineers *feel* how architectures behave under load
  and failure (bottlenecks, cascading failures, the value of replicas and caches).
- **Design validation:** sketch a system, push traffic through it, and see where it breaks
  before building it for real.
- **Chaos intuition:** inject realistic faults (crashes, AZ outages, packet loss, high
  latency) and observe the blast radius live.

## Core principle: NO fake data

Every number shown in the UI is **computed by the simulation engine from the user's design
and inputs** — never hard-coded or mocked. If you add a metric, derive it from the engine's
output. Treat this as a hard rule.

## Architecture

```
Browser (no backend yet)
  React UI ── Zustand store ──(postMessage)──> Web Worker ── simEngine.simulate()
     ▲                                              │
     └───────────── metrics / edge flows ◀──────────┘
```

- **Simulation runs client-side in a Web Worker** — keeps the UI smooth and means the app
  costs almost nothing to host even at high traffic.
- The engine is **pure** (`src/engine/simEngine.ts`): `simulate(design, trafficQps, chaos)`
  returns per-node metrics, per-edge flows, and totals. No DOM, no React.
- The worker (`src/workers/sim.worker.ts`) runs the engine on a timer and posts results back.
- The store (`src/store/useDesignStore.ts`) owns design state + worker lifecycle and writes
  results back onto nodes/edges so React Flow can render them.

## Simulation model (how the math works)

Steady-state queueing-network approximation, recomputed each tick:

- **Effective capacity (μ)** = `capacityQps × replicas × availability × chaosMultiplier`.
- **Arrival rates (λ)** propagate from source nodes (no inbound edges) downstream via
  relaxation iterations. **Routing depends on `NodeRole`:** `balancer` splits its served
  traffic equally across successors; everything else fans out (a request hitting an App
  Server also touches its Cache and Database).
- **Utilization (ρ)** = `λ / μ`. **Latency** = `baseLatency / (1 − ρ)` (grows sharply near
  saturation; clamped when saturated). **Drops** = `λ − served`. **Errors** reduce served.
- **End-to-end latency** = longest (critical) path of per-node latencies.
- **Success rate** = throughput / offered traffic. **Bandwidth** = Σ(served × payloadKb).
- **SPOF detection:** a load-bearing single-replica node whose removal disconnects
  otherwise-reachable nodes from all sources is flagged.

When changing the model, keep it explainable and consistent with these definitions.

## Tech stack

Vite · React · TypeScript · React Flow (canvas) · Zustand (state) · Tailwind CSS · Recharts ·
Web Worker. No backend yet (planned: Supabase + an AI proxy).

## Project structure

```
src/
  canvas/      Canvas.tsx (React Flow + grid + drag/drop), nodeTypes.tsx (node card,
               LOAD%/SPOF badges, delete), FlowEdge.tsx (animated traffic dots)
  engine/      simEngine.ts — pure queueing-network simulation
  workers/     sim.worker.ts — runs the engine on a timer
  store/       useDesignStore.ts — Zustand state + worker messaging
  components/  Toolbar, TopMetricsBar (RPS/latency/success/bandwidth), LeftPanel
               (Presets/Components/Chaos tabs, draggable), Inspector (Component Settings),
               MetricsPanel (charts), BottomBar (START/RESET + Traffic/Speed sliders)
  lib/         defaultDesign.ts, presets.ts
  types/       index.ts — all shared types + NODE_META + CHAOS_META + presets metadata
```

## Key domain types (`src/types/index.ts`)

- `NodeKind` (17 kinds) grouped by `NodeCategory` (Network/Compute/Data/Messaging) with a
  routing `NodeRole` (entry/balancer/service/store). `NODE_META` holds title/icon/color/defaults.
- `NodeConfig`: `capacityQps`, `baseLatencyMs`, `replicas`, `errorRatePct`, `payloadKb`,
  `availabilityPct`.
- `ChaosType` (16 types) grouped by `ChaosCategory`. `CHAOS_META` holds label/icon/description.
- `SimResult` = `{ perNode, edgeFlows, totals }`. Engine ↔ worker ↔ store all share these.

## Commands

```powershell
npm install
npm run dev      # dev server at http://localhost:5173
npm run build    # tsc -b && vite build  (must pass before considering work done)
npm run preview  # preview the production build
```

## Conventions for agents

- **Validate with `npm run build`** after changes; fix all TypeScript errors.
- Keep the engine pure and deterministic; put timing/IO in the worker.
- New components go in `NODE_META`; new failures go in `CHAOS_META` with a real effect in
  `chaosEffect()`. New starter graphs go in `src/lib/presets.ts`.
- Don't introduce mocked/placeholder metrics. Derive everything from `simulate()`.
- Match the dark, square-grid paperdraw-style UI; prefer Tailwind utility classes.

## Roadmap (future phases)

- Persistence & accounts (Supabase), shareable links, public library.
- Freemium gating + design challenges.
- AI layer (Pro): analyze a simulation for suggestions; generate a design from a prompt
  (must output validated `{nodes, edges}` JSON via a backend proxy with auth + quotas).

See also: [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md), [TASKS.md](TASKS.md), [README.md](README.md).
