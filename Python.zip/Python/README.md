# System Design Simulator

An interactive, browser-based **system-design simulator** (inspired by paperdraw.dev).
Build an architecture on a canvas, run a **discrete-event simulation** with adjustable
traffic, inject **chaos** (failures), and watch live metrics react.

> Full plan: [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) · Task list: [TASKS.md](TASKS.md)

## Features (implemented)

- **Visual canvas** (React Flow) with typed nodes: API Gateway, Load Balancer,
  App Server, Cache (Redis), Database (Postgres).
- **Inspector** to edit each node's capacity (qps/replica), base latency, and replicas.
- **Client-side simulation engine** running in a **Web Worker** (queueing-network model).
- **Traffic** (QPS) and **Speed** sliders; START / STOP / RESET.
- **Live metrics**: throughput, dropped qps, p50 / p99 latency, per-node utilization,
  plus a time-series chart.
- **Node health coloring** (green → amber → red) and animated edges.
- **Chaos engineering**: instance crash, CPU spike, disk failure, packet loss,
  high latency, network partition — applied live mid-simulation.
- **Save / Load** designs to `localStorage`.

## Tech stack

Vite · React · TypeScript · React Flow · Zustand · Tailwind CSS · Recharts · Web Worker.

## Getting started

```powershell
npm install
npm run dev      # start dev server at http://localhost:5173
npm run build    # type-check + production build
npm run preview  # preview the production build
```

## How the simulation works

The engine ([src/engine/simEngine.ts](src/engine/simEngine.ts)) treats each node as a
service center: effective capacity = `capacityQps × replicas`. It propagates arrival
rates from source nodes (no inbound edges) downstream — load balancers split load across
successors, other nodes fan out — then computes utilization, queueing latency
(`baseLatency / (1 - ρ)`), and drops (`offered − capacity`). End-to-end latency is the
critical (longest) path. It runs on a timer inside a Web Worker
([src/workers/sim.worker.ts](src/workers/sim.worker.ts)) and posts metrics back to the UI.

Chaos events mutate a node's effective capacity / latency / loss at runtime, so metrics
respond immediately.

## Project structure

```
src/
  canvas/      React Flow canvas + custom node components
  engine/      simEngine.ts — queueing-network simulation (pure)
  workers/     sim.worker.ts — runs the engine on a timer
  store/       Zustand store + worker lifecycle
  components/  Toolbar, LeftPanel (palette + inspector), ChaosPanel, MetricsPanel, BottomBar
  types/       shared types + node metadata/defaults
  lib/         default preset design
```

## Documentation

Full docs — architecture, the M/M/c + Erlang-C engine (with diagrams), deployment, and
future enhancements — are in [DOCS.md](DOCS.md).

## Roadmap (next phases)

- Persistence & accounts (Supabase), shareable links, public library.
- Freemium gating + design challenges.
- AI layer (Pro): analyze a simulation for suggestions, and generate a design from a prompt.

