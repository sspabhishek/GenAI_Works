/* Standalone accuracy validation for components, chaos, and presets.
 * Run with:  npx tsx scripts/validate.ts
 * Exits non-zero if any check fails. No DOM dependencies. */
import {
  NODE_META,
  NODE_CATEGORIES,
  CHAOS_META,
  CHAOS_CATEGORIES,
  type ChaosType,
  type NodeKind,
} from '../src/types/index.ts';
import { simulate } from '../src/engine/simEngine.ts';
import { PRESETS, buildPreset } from '../src/lib/presets.ts';

let failures = 0;
const fail = (msg: string) => {
  failures++;
  console.error('  ✗ ' + msg);
};
const ok = (msg: string) => console.log('  ✓ ' + msg);

function finite(n: number): boolean {
  return typeof n === 'number' && Number.isFinite(n);
}

// 1) Components ---------------------------------------------------------------
console.log('\n[1] Components');
const kinds = Object.keys(NODE_META) as NodeKind[];
for (const k of kinds) {
  const m = NODE_META[k];
  if (!m.title) fail(`${k}: missing title`);
  if (!NODE_CATEGORIES.includes(m.category)) fail(`${k}: bad category ${m.category}`);
  if (!['entry', 'balancer', 'service', 'store'].includes(m.role))
    fail(`${k}: bad role ${m.role}`);
  if (!m.icon) fail(`${k}: missing icon`);
  if (!m.description || m.description.length < 30) fail(`${k}: weak/no description`);
  const c = m.defaults;
  if (!finite(c.capacityQps) || c.capacityQps <= 0) fail(`${k}: bad capacityQps`);
  if (!finite(c.baseLatencyMs) || c.baseLatencyMs < 0) fail(`${k}: bad baseLatencyMs`);
  if (!finite(c.replicas) || c.replicas < 1) fail(`${k}: bad replicas`);
  if (!finite(c.payloadKb) || c.payloadKb < 0) fail(`${k}: bad payloadKb`);
  if (!finite(c.availabilityPct) || c.availabilityPct <= 0 || c.availabilityPct > 100)
    fail(`${k}: bad availabilityPct`);
}
ok(`${kinds.length} components across ${NODE_CATEGORIES.length} categories validated`);

// 2) Chaos --------------------------------------------------------------------
console.log('\n[2] Chaos');
const chaosTypes = Object.keys(CHAOS_META) as ChaosType[];
// A single-node design to measure each chaos effect against baseline.
const probe = {
  nodes: [
    {
      id: 'n',
      type: 'sim',
      position: { x: 0, y: 0 },
      data: { label: 'n', kind: 'appServer' as NodeKind, config: { ...NODE_META.appServer.defaults } },
    },
  ],
  edges: [],
};
const baseline = simulate(probe as never, 1000, []);
const baseNode = baseline.perNode[0];
for (const t of chaosTypes) {
  const m = CHAOS_META[t];
  if (!m.label) fail(`${t}: missing label`);
  if (!CHAOS_CATEGORIES.includes(m.category)) fail(`${t}: bad category ${m.category}`);
  if (!m.icon) fail(`${t}: missing icon`);
  if (!m.description || m.description.length < 15) fail(`${t}: weak/no description`);
  // The chaos must measurably change something vs baseline.
  const r = simulate(probe as never, 1000, [{ nodeId: 'n', type: t }]);
  const n = r.perNode[0];
  const changed =
    Math.abs(n.servedQps - baseNode.servedQps) > 0.01 ||
    Math.abs(n.latencyMs - baseNode.latencyMs) > 0.01 ||
    Math.abs(n.droppedQps - baseNode.droppedQps) > 0.01 ||
    n.status !== baseNode.status;
  if (!changed) fail(`${t}: has NO measurable effect on the simulation`);
  if (!finite(n.latencyMs) || !finite(n.servedQps)) fail(`${t}: produced non-finite metrics`);
}
ok(`${chaosTypes.length} chaos types across ${CHAOS_CATEGORIES.length} categories validated`);

// 3) Presets ------------------------------------------------------------------
console.log('\n[3] Presets');
for (const p of PRESETS) {
  const d = buildPreset(p.id);
  const ids = new Set(d.nodes.map((n) => n.id));
  if (ids.size !== d.nodes.length) fail(`${p.id}: duplicate node ids`);
  for (const e of d.edges) {
    if (!ids.has(e.source)) fail(`${p.id}: edge source '${e.source}' missing`);
    if (!ids.has(e.target)) fail(`${p.id}: edge target '${e.target}' missing`);
    if (e.type !== 'flow') fail(`${p.id}: edge ${e.id} not type 'flow'`);
  }
  for (const n of d.nodes) {
    if (!NODE_META[n.data.kind]) fail(`${p.id}: node '${n.id}' has unknown kind ${n.data.kind}`);
  }
  const indeg = new Map<string, number>();
  d.nodes.forEach((n) => indeg.set(n.id, 0));
  d.edges.forEach((e) => indeg.set(e.target, (indeg.get(e.target) ?? 0) + 1));
  const sources = d.nodes.filter((n) => (indeg.get(n.id) ?? 0) === 0);
  if (sources.length === 0) fail(`${p.id}: NO source node (every node has inbound edges)`);
  // Engine must produce sane, finite totals at a realistic load.
  const r = simulate(d, 5000, []);
  const ttl = r.totals;
  if (!finite(ttl.throughputQps) || ttl.throughputQps < 0) fail(`${p.id}: bad throughput`);
  if (!finite(ttl.p99LatencyMs) || ttl.p99LatencyMs < 0) fail(`${p.id}: bad p99`);
  if (!finite(ttl.successRatePct) || ttl.successRatePct < 0 || ttl.successRatePct > 100)
    fail(`${p.id}: success% out of range (${ttl.successRatePct})`);
  if (!finite(ttl.bandwidthMBs) || ttl.bandwidthMBs < 0) fail(`${p.id}: bad bandwidth`);
  for (const nm of r.perNode) {
    if (!finite(nm.latencyMs) || !finite(nm.utilization)) fail(`${p.id}: node ${nm.id} non-finite`);
  }
  ok(
    `${p.id}: ${d.nodes.length} nodes, ${d.edges.length} edges, ${sources.length} source(s) → ` +
      `${Math.round(ttl.throughputQps)} rps, ${ttl.successRatePct.toFixed(1)}% success`,
  );
}

console.log('');
if (failures > 0) {
  console.error(`VALIDATION FAILED: ${failures} issue(s).`);
  process.exit(1);
} else {
  console.log('ALL CHECKS PASSED.');
}
