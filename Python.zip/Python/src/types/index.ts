import type { Node, Edge } from 'reactflow';
import type { LucideIcon } from 'lucide-react';
import {
  Activity,
  Boxes,
  BrainCircuit,
  Cloud,
  Cpu,
  Database,
  Filter,
  FileSearch,
  Gauge,
  GitBranch,
  GitMerge,
  Globe,
  HardDrive,
  KeyRound,
  Layers,
  LineChart,
  Lock,
  Network,
  Radio,
  Router,
  Search,
  Server,
  Share2,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Siren,
  Table2,
  Telescope,
  Boxes as BoxesIcon,
  Workflow,
  Waypoints,
  Zap,
  Bot,
  Wrench as WrenchIcon,
  ScrollText,
  Bell,
  Image as ImageIcon,
  CalendarClock,
  Container,
  // chaos icons
  CloudOff,
  Flame,
  HardDriveDownload,
  MemoryStick,
  ServerCrash,
  Snail,
  Timer,
  Unplug,
  Wrench,
  Building2,
  Scissors,
  CircuitBoard,
  Skull,
  GitFork,
  Hourglass,
  RefreshCw,
  Bug,
  TrendingUp,
  Users as UsersIcon,
  Clock,
  PackageX,
  DatabaseBackup,
  CopyX,
  Lock as LockIcon,
  Crosshair,
} from 'lucide-react';

export type NodeKind =
  // Network & Edge
  | 'apiGateway'
  | 'loadBalancer'
  | 'reverseProxy'
  | 'cdn'
  | 'dns'
  | 'rateLimiter'
  | 'firewall'
  | 'serviceMesh'
  | 'natGateway'
  | 'vpnGateway'
  // Compute
  | 'appServer'
  | 'serverless'
  | 'worker'
  | 'authService'
  | 'scheduler'
  | 'mediaProcessor'
  | 'notificationService'
  | 'searchService'
  // Data & Storage
  | 'database'
  | 'cache'
  | 'objectStorage'
  | 'searchIndex'
  | 'kvStore'
  | 'graphDb'
  | 'timeSeriesDb'
  | 'dataWarehouse'
  | 'dataLake'
  | 'vectorDb'
  // Messaging
  | 'messageQueue'
  | 'eventStream'
  | 'pubsub'
  // AI & Agents
  | 'llmGateway'
  | 'agentOrchestrator'
  | 'toolRegistry'
  // Security
  | 'ddosShield'
  | 'siem'
  | 'secretsManager'
  | 'hsm'
  | 'fraudDetection'
  // Observability
  | 'logAggregator'
  | 'metricsCollector'
  | 'tracing'
  | 'alerting'
  // Data Engineering
  | 'etlPipeline'
  | 'cdcService'
  | 'batchProcessor'
  | 'featureStore'
  | 'schemaRegistry';

export type NodeCategory =
  | 'Network & Edge'
  | 'Compute'
  | 'Data & Storage'
  | 'Messaging'
  | 'AI & Agents'
  | 'Security'
  | 'Observability'
  | 'Data Engineering';

/** How a node routes traffic to its successors in the simulation. */
export type NodeRole = 'entry' | 'balancer' | 'service' | 'store';

export interface NodeConfig {
  /** Requests/sec a single replica can serve. */
  capacityQps: number;
  /** Base service time in ms (no queueing). */
  baseLatencyMs: number;
  /** Number of replicas. */
  replicas: number;
  /** Baseline percentage of admitted requests that error out (0-100). */
  errorRatePct: number;
  /** Average response payload size in KB (used for bandwidth). */
  payloadKb: number;
  /** Availability SLA as a percentage; reduces average effective capacity. */
  availabilityPct: number;
}

/** Selectable availability tiers for the settings dropdown. */
export const AVAILABILITY_TIERS = [
  { label: '90% (1 nine)', value: 90 },
  { label: '99% (2 nines)', value: 99 },
  { label: '99.9% (3 nines)', value: 99.9 },
  { label: '99.99% (4 nines)', value: 99.99 },
  { label: '99.999% (5 nines)', value: 99.999 },
] as const;

export type NodeStatus = 'ok' | 'degraded' | 'down';

export interface SimNodeData {
  label: string;
  kind: NodeKind;
  config: NodeConfig;
  /** Runtime values written back from the simulation. */
  utilization?: number; // 0..1+
  status?: NodeStatus;
  inRateQps?: number;
  servedQps?: number;
  droppedQps?: number;
  latencyMs?: number;
  successRatePct?: number;
  /** Whether this node is a single point of failure (computed). */
  spof?: boolean;
}

export type SimNode = Node<SimNodeData>;

export interface SimEdgeData {
  /** Live flow rate on this edge (qps), written by the simulation. */
  flowQps?: number;
  /** Source node health, used to color/animate the edge. */
  health?: NodeStatus;
}

export type SimEdge = Edge<SimEdgeData>;

export interface Design {
  nodes: SimNode[];
  edges: SimEdge[];
}

/** Runtime chaos applied to a node. */
export type ChaosType =
  // Infrastructure failures
  | 'crash'
  | 'cpuSpike'
  | 'diskFailure'
  | 'instanceSlow'
  | 'memoryLeak'
  | 'availabilityZone'
  | 'dataCenter'
  | 'diskCorruption'
  | 'storageIops'
  | 'hostHardware'
  // Network chaos
  | 'packetLoss'
  | 'highLatency'
  | 'partition'
  | 'bandwidthThrottle'
  | 'crossRegion'
  | 'connectionFlapping'
  | 'dnsFailure'
  | 'tlsHandshake'
  // Application-level chaos
  | 'memoryLeakApp'
  | 'threadPoolExhaustion'
  | 'deadlock'
  | 'gcPause'
  | 'configDrift'
  | 'deploymentMisconfig'
  // Data layer chaos
  | 'dbPrimaryFailover'
  | 'replicaFailure'
  | 'replicationLag'
  | 'splitBrain'
  | 'hotShard'
  | 'connectionPoolExhaustion'
  | 'lockContention'
  | 'cachePoisoning'
  | 'cacheStampede'
  // Traffic chaos
  | 'trafficSpike'
  | 'retryStorm'
  | 'botTraffic'
  | 'thunderingHerd'
  | 'payloadBloat'
  // Dependency chaos
  | 'thirdPartyOutage'
  | 'authOutage'
  | 'serviceDiscoveryFailure'
  | 'clockSkew';

export type ChaosCategory =
  | 'Infrastructure Failures'
  | 'Network Chaos'
  | 'Application-Level Chaos'
  | 'Data Layer Chaos'
  | 'Traffic Chaos'
  | 'Dependency Chaos';

export interface ChaosEvent {
  nodeId: string;
  type: ChaosType;
}

export interface NodeMetric {
  id: string;
  inRateQps: number;
  servedQps: number;
  droppedQps: number;
  utilization: number; // 0..1+
  latencyMs: number;
  status: NodeStatus;
  successRatePct: number;
  spof: boolean;
}

export interface EdgeFlow {
  id: string;
  flowQps: number;
  health: NodeStatus;
}

export interface SimTotals {
  throughputQps: number;
  droppedQps: number;
  p50LatencyMs: number;
  p99LatencyMs: number;
  offeredQps: number;
  successRatePct: number;
  bandwidthMBs: number;
}

export interface SeriesPoint {
  t: number;
  throughput: number;
  p99: number;
  dropped: number;
  success: number;
}

export interface SimResult {
  perNode: NodeMetric[];
  edgeFlows: EdgeFlow[];
  totals: SimTotals;
}

/** Messages: main thread -> worker */
export type ToWorker =
  | { type: 'init'; design: Design }
  | { type: 'params'; trafficQps: number; speed: number }
  | { type: 'start' }
  | { type: 'stop' }
  | { type: 'chaos'; event: ChaosEvent }
  | { type: 'clearChaos' };

/** Messages: worker -> main thread */
export type FromWorker = {
  type: 'metrics';
  result: SimResult;
  point: SeriesPoint;
};

export interface NodeMetaEntry {
  title: string;
  category: NodeCategory;
  role: NodeRole;
  icon: LucideIcon;
  color: string;
  /** Short overview shown on hover: what it is and why you'd use it. */
  description: string;
  defaults: NodeConfig;
}

const cfg = (
  capacityQps: number,
  baseLatencyMs: number,
  replicas: number,
  payloadKb = 4,
  errorRatePct = 0,
  availabilityPct = 99.9,
): NodeConfig => ({
  capacityQps,
  baseLatencyMs,
  replicas,
  errorRatePct,
  payloadKb,
  availabilityPct,
});

export const NODE_META: Record<NodeKind, NodeMetaEntry> = {
  // ── Network & Edge ──────────────────────────────────────────────
  apiGateway: {
    title: 'API Gateway',
    category: 'Network & Edge',
    role: 'entry',
    icon: Network,
    color: '#60a5fa',
    description:
      'Single entry point that routes, authenticates, and rate-limits API requests to backend services. Use it to centralize cross-cutting concerns instead of duplicating them per service.',
    defaults: cfg(5000, 2, 1),
  },
  loadBalancer: {
    title: 'Load Balancer',
    category: 'Network & Edge',
    role: 'balancer',
    icon: Waypoints,
    color: '#38bdf8',
    description:
      'Distributes incoming traffic across multiple backend replicas to spread load and improve availability. Essential for horizontal scaling and removing single points of failure.',
    defaults: cfg(8000, 1, 1),
  },
  reverseProxy: {
    title: 'Reverse Proxy',
    category: 'Network & Edge',
    role: 'balancer',
    icon: GitBranch,
    color: '#22d3ee',
    description:
      'Sits in front of servers to terminate TLS, cache responses, and forward requests. Use it for SSL offload, compression, and hiding backend topology.',
    defaults: cfg(7000, 1, 1),
  },
  cdn: {
    title: 'CDN',
    category: 'Network & Edge',
    role: 'entry',
    icon: Globe,
    color: '#818cf8',
    description:
      'Geographically distributed edge caches that serve static assets close to users. Use it to cut latency and offload origin servers for images, video, and JS/CSS.',
    defaults: cfg(20000, 5, 1, 64),
  },
  dns: {
    title: 'DNS',
    category: 'Network & Edge',
    role: 'entry',
    icon: Router,
    color: '#a5b4fc',
    description:
      'Resolves domain names to IP addresses and can route users to the nearest region. Use it for service discovery and geo/latency-based routing.',
    defaults: cfg(30000, 3, 1),
  },
  rateLimiter: {
    title: 'Rate Limiter',
    category: 'Network & Edge',
    role: 'service',
    icon: Gauge,
    color: '#fbbf24',
    description:
      'Caps how many requests a client can make in a window to protect downstream services. Use it to prevent abuse, ensure fairness, and absorb traffic spikes.',
    defaults: cfg(15000, 1, 1),
  },
  firewall: {
    title: 'Firewall / WAF',
    category: 'Network & Edge',
    role: 'entry',
    icon: ShieldCheck,
    color: '#f87171',
    description:
      'Web Application Firewall that filters malicious traffic (SQLi, XSS, bots) before it reaches your app. Use it as a security gate at the network edge.',
    defaults: cfg(12000, 2, 1),
  },
  serviceMesh: {
    title: 'Service Mesh',
    category: 'Network & Edge',
    role: 'balancer',
    icon: Share2,
    color: '#7dd3fc',
    description:
      'Sidecar-based layer (e.g. Istio/Linkerd) managing service-to-service traffic, mTLS, retries, and observability. Use it to standardize comms in large microservice fleets.',
    defaults: cfg(9000, 2, 2),
  },
  natGateway: {
    title: 'NAT Gateway',
    category: 'Network & Edge',
    role: 'service',
    icon: Router,
    color: '#93c5fd',
    description:
      'Lets instances in a private subnet reach the internet for outbound traffic without exposing them inbound. Use it for secure egress from private networks.',
    defaults: cfg(10000, 2, 1),
  },
  vpnGateway: {
    title: 'VPN Gateway',
    category: 'Network & Edge',
    role: 'entry',
    icon: Lock,
    color: '#67e8f9',
    description:
      'Encrypted tunnel connecting on-prem networks or remote users to your cloud VPC. Use it for hybrid-cloud and secure private connectivity.',
    defaults: cfg(4000, 8, 1),
  },
  // ── Compute ─────────────────────────────────────────────────────
  appServer: {
    title: 'App Server',
    category: 'Compute',
    role: 'service',
    icon: Server,
    color: '#a78bfa',
    description:
      'Runs your application/business logic and handles requests. The workhorse tier — scale it horizontally behind a load balancer to add capacity.',
    defaults: cfg(500, 20, 3),
  },
  serverless: {
    title: 'Serverless Fn',
    category: 'Compute',
    role: 'service',
    icon: Zap,
    color: '#c084fc',
    description:
      'Event-driven functions (Lambda/Cloud Functions) that auto-scale per request with no servers to manage. Use for spiky or low-baseline workloads; watch cold starts.',
    defaults: cfg(200, 35, 5),
  },
  worker: {
    title: 'Worker',
    category: 'Compute',
    role: 'service',
    icon: Cpu,
    color: '#d8b4fe',
    description:
      'Background processor that consumes jobs from a queue (emails, thumbnails, ETL). Use it to do slow work asynchronously, decoupled from the request path.',
    defaults: cfg(300, 50, 2),
  },
  authService: {
    title: 'Auth Service',
    category: 'Compute',
    role: 'service',
    icon: KeyRound,
    color: '#f0abfc',
    description:
      'Issues and validates tokens/sessions (OAuth, JWT, OIDC). Centralizes identity so every service can verify who the caller is.',
    defaults: cfg(1500, 10, 2),
  },
  scheduler: {
    title: 'Scheduler',
    category: 'Compute',
    role: 'service',
    icon: CalendarClock,
    color: '#c4b5fd',
    description:
      'Triggers periodic or delayed jobs (cron, batch windows). Use it to kick off recurring tasks like reports, cleanups, and billing runs.',
    defaults: cfg(2000, 5, 1),
  },
  mediaProcessor: {
    title: 'Media Processor',
    category: 'Compute',
    role: 'service',
    icon: ImageIcon,
    color: '#e9d5ff',
    description:
      'Transcodes and resizes images/video/audio. CPU-heavy and slow — run it asynchronously via workers and store outputs in object storage.',
    defaults: cfg(120, 120, 3),
  },
  notificationService: {
    title: 'Notification Service',
    category: 'Compute',
    role: 'service',
    icon: Bell,
    color: '#ddd6fe',
    description:
      'Sends push, email, and SMS notifications, usually fanning out from a queue. Use it to decouple user messaging from core request flows.',
    defaults: cfg(2500, 15, 2),
  },
  searchService: {
    title: 'Search Service',
    category: 'Compute',
    role: 'service',
    icon: FileSearch,
    color: '#a5f3fc',
    description:
      'Query API in front of a search index that handles relevance, filters, and pagination. Use it for full-text and faceted search instead of LIKE queries on a DB.',
    defaults: cfg(1500, 18, 2),
  },
  // ── Data & Storage ──────────────────────────────────────────────
  database: {
    title: 'Database',
    category: 'Data & Storage',
    role: 'store',
    icon: Database,
    color: '#34d399',
    description:
      'Relational store (Postgres/MySQL) with ACID transactions and strong consistency. Use it as the source of truth for structured, related data.',
    defaults: cfg(800, 8, 1),
  },
  cache: {
    title: 'Cache (Redis)',
    category: 'Data & Storage',
    role: 'store',
    icon: Zap,
    color: '#f472b6',
    description:
      'In-memory key/value store for hot data. Use it to absorb read load and cut latency — but plan for invalidation and stampedes.',
    defaults: cfg(10000, 1, 1, 2),
  },
  objectStorage: {
    title: 'Object Storage',
    category: 'Data & Storage',
    role: 'store',
    icon: HardDrive,
    color: '#2dd4bf',
    description:
      'Durable blob storage (S3/GCS) for files, images, backups, and static assets. Cheap, virtually infinite, and best paired with a CDN.',
    defaults: cfg(5000, 15, 1, 256),
  },
  searchIndex: {
    title: 'Search Index',
    category: 'Data & Storage',
    role: 'store',
    icon: Search,
    color: '#4ade80',
    description:
      'Inverted-index engine (Elasticsearch/OpenSearch) optimized for full-text and analytics queries. Keep it in sync with your DB via CDC or streams.',
    defaults: cfg(1200, 12, 2),
  },
  kvStore: {
    title: 'KV Store',
    category: 'Data & Storage',
    role: 'store',
    icon: Table2,
    color: '#6ee7b7',
    description:
      'Distributed key/value database (DynamoDB/Cassandra) with massive horizontal scale and tunable consistency. Use it for high-throughput access by key.',
    defaults: cfg(15000, 5, 1),
  },
  graphDb: {
    title: 'Graph DB',
    category: 'Data & Storage',
    role: 'store',
    icon: Share2,
    color: '#5eead4',
    description:
      'Stores nodes and relationships (Neo4j) for traversal-heavy queries. Use it for social graphs, recommendations, and fraud rings.',
    defaults: cfg(900, 14, 1),
  },
  timeSeriesDb: {
    title: 'Time Series DB',
    category: 'Data & Storage',
    role: 'store',
    icon: LineChart,
    color: '#34d399',
    description:
      'Optimized for timestamped metrics/events (Prometheus/InfluxDB). Use it for monitoring, IoT, and any append-heavy time-ordered data.',
    defaults: cfg(8000, 6, 1),
  },
  dataWarehouse: {
    title: 'Data Warehouse',
    category: 'Data & Storage',
    role: 'store',
    icon: Building2,
    color: '#10b981',
    description:
      'Columnar analytical store (Snowflake/BigQuery/Redshift) for large OLAP queries. Use it for BI and reporting, fed by ETL — not for live app traffic.',
    defaults: cfg(400, 80, 1),
  },
  dataLake: {
    title: 'Data Lake',
    category: 'Data & Storage',
    role: 'store',
    icon: Cloud,
    color: '#2dd4bf',
    description:
      'Raw, schema-on-read storage for structured and unstructured data at scale. Use it as the landing zone before transforming data for analytics/ML.',
    defaults: cfg(3000, 40, 1, 128),
  },
  vectorDb: {
    title: 'Vector DB',
    category: 'Data & Storage',
    role: 'store',
    icon: BoxesIcon,
    color: '#5eead4',
    description:
      'Stores embeddings and does similarity search (Pinecone/pgvector). Core of RAG and semantic search — query it with a query vector to find nearest neighbors.',
    defaults: cfg(2000, 20, 2),
  },
  // ── Messaging ───────────────────────────────────────────────────
  messageQueue: {
    title: 'Message Queue',
    category: 'Messaging',
    role: 'store',
    icon: Layers,
    color: '#fb923c',
    description:
      'Buffers work between producers and consumers (RabbitMQ/SQS). Use it to smooth spikes, decouple services, and retry failed jobs.',
    defaults: cfg(6000, 4, 1),
  },
  eventStream: {
    title: 'Event Stream',
    category: 'Messaging',
    role: 'store',
    icon: Activity,
    color: '#fdba74',
    description:
      'Durable, replayable log of events (Kafka/Kinesis) with many consumers. Use it for event sourcing, analytics pipelines, and high-throughput fan-out.',
    defaults: cfg(9000, 3, 1),
  },
  pubsub: {
    title: 'Pub/Sub',
    category: 'Messaging',
    role: 'store',
    icon: Radio,
    color: '#fdba74',
    description:
      'Topic-based broadcast where publishers send and many subscribers receive. Use it for real-time fan-out like notifications and cache invalidation.',
    defaults: cfg(12000, 3, 1),
  },
  // ── AI & Agents ─────────────────────────────────────────────────
  llmGateway: {
    title: 'LLM Gateway',
    category: 'AI & Agents',
    role: 'service',
    icon: BrainCircuit,
    color: '#c084fc',
    description:
      'Proxy for large language model calls with auth, quotas, caching, and provider routing. Use it to control cost and centralize prompts/safety.',
    defaults: cfg(150, 300, 3, 8),
  },
  agentOrchestrator: {
    title: 'Agent Orchestrator',
    category: 'AI & Agents',
    role: 'service',
    icon: Workflow,
    color: '#d8b4fe',
    description:
      'Coordinates multi-step AI agent workflows, tool calls, and memory. Use it to chain LLM reasoning with external actions reliably.',
    defaults: cfg(100, 250, 2),
  },
  toolRegistry: {
    title: 'Tool Registry',
    category: 'AI & Agents',
    role: 'service',
    icon: WrenchIcon,
    color: '#e9d5ff',
    description:
      'Catalog of tools/functions an agent can invoke, with schemas and permissions. Use it so agents discover and call capabilities safely.',
    defaults: cfg(3000, 8, 1),
  },
  // ── Security ────────────────────────────────────────────────────
  ddosShield: {
    title: 'DDoS Shield',
    category: 'Security',
    role: 'entry',
    icon: Shield,
    color: '#f87171',
    description:
      'Absorbs and scrubs volumetric attack traffic at the edge before it reaches you. Use it to stay available under floods.',
    defaults: cfg(50000, 1, 1),
  },
  siem: {
    title: 'SIEM',
    category: 'Security',
    role: 'service',
    icon: ShieldAlert,
    color: '#fca5a5',
    description:
      'Aggregates and correlates security logs to detect threats and raise alerts. Use it for monitoring, compliance, and incident response.',
    defaults: cfg(4000, 20, 1),
  },
  secretsManager: {
    title: 'Secrets Manager',
    category: 'Security',
    role: 'service',
    icon: KeyRound,
    color: '#fdba74',
    description:
      'Securely stores and rotates credentials, API keys, and certificates (Vault). Use it so secrets never live in code or config files.',
    defaults: cfg(5000, 6, 2),
  },
  hsm: {
    title: 'HSM',
    category: 'Security',
    role: 'service',
    icon: Lock,
    color: '#fb7185',
    description:
      'Hardware Security Module that safeguards cryptographic keys and signing. Use it for high-assurance encryption, PKI, and payment systems.',
    defaults: cfg(1000, 12, 1),
  },
  fraudDetection: {
    title: 'Fraud Detection',
    category: 'Security',
    role: 'service',
    icon: ShieldAlert,
    color: '#f87171',
    description:
      'Scores transactions/events in real time to flag fraud and abuse. Use it inline in payment and signup flows to block bad actors.',
    defaults: cfg(2000, 25, 2),
  },
  // ── Observability ───────────────────────────────────────────────
  logAggregator: {
    title: 'Log Aggregator',
    category: 'Observability',
    role: 'store',
    icon: ScrollText,
    color: '#fbbf24',
    description:
      'Centralizes logs from all services for search and analysis (ELK/Loki). Use it to debug across distributed systems from one place.',
    defaults: cfg(7000, 8, 1),
  },
  metricsCollector: {
    title: 'Metrics Collector',
    category: 'Observability',
    role: 'service',
    icon: LineChart,
    color: '#facc15',
    description:
      'Scrapes and stores metrics from services (Prometheus). Use it to power dashboards, SLOs, and alerting.',
    defaults: cfg(10000, 4, 1),
  },
  tracing: {
    title: 'Distributed Tracing',
    category: 'Observability',
    role: 'service',
    icon: Telescope,
    color: '#fde047',
    description:
      'Tracks a request across many services with spans (Jaeger/OTel). Use it to find latency bottlenecks in microservice call chains.',
    defaults: cfg(8000, 6, 1),
  },
  alerting: {
    title: 'Alerting Engine',
    category: 'Observability',
    role: 'service',
    icon: Siren,
    color: '#fbbf24',
    description:
      'Evaluates rules on metrics/logs and pages on-call when thresholds breach. Use it to turn telemetry into timely incident response.',
    defaults: cfg(5000, 6, 1),
  },
  // ── Data Engineering ────────────────────────────────────────────
  etlPipeline: {
    title: 'ETL Pipeline',
    category: 'Data Engineering',
    role: 'service',
    icon: Workflow,
    color: '#a78bfa',
    description:
      'Extracts, transforms, and loads data between systems on a schedule. Use it to move app data into the warehouse for analytics.',
    defaults: cfg(600, 60, 2),
  },
  cdcService: {
    title: 'CDC Service',
    category: 'Data Engineering',
    role: 'service',
    icon: GitMerge,
    color: '#c084fc',
    description:
      'Change Data Capture streams row-level DB changes downstream (Debezium). Use it to keep caches, search, and warehouses in sync in near real-time.',
    defaults: cfg(4000, 10, 1),
  },
  batchProcessor: {
    title: 'Batch Processor',
    category: 'Data Engineering',
    role: 'service',
    icon: Boxes,
    color: '#d8b4fe',
    description:
      'Runs large parallel jobs over big datasets (Spark/MapReduce). Use it for periodic heavy computation like aggregations and ML feature builds.',
    defaults: cfg(300, 100, 4),
  },
  featureStore: {
    title: 'Feature Store',
    category: 'Data Engineering',
    role: 'store',
    icon: Container,
    color: '#34d399',
    description:
      'Serves consistent ML features for training and low-latency inference. Use it to avoid training/serving skew across models.',
    defaults: cfg(6000, 8, 2),
  },
  schemaRegistry: {
    title: 'Schema Registry',
    category: 'Data Engineering',
    role: 'service',
    icon: GitFork,
    color: '#c4b5fd',
    description:
      'Stores and validates message schemas (Avro/Protobuf) for streams. Use it to evolve event formats safely without breaking consumers.',
    defaults: cfg(8000, 4, 1),
  },
};

export const NODE_CATEGORIES: NodeCategory[] = [
  'Network & Edge',
  'Compute',
  'Data & Storage',
  'Messaging',
  'AI & Agents',
  'Security',
  'Observability',
  'Data Engineering',
];

export interface ChaosMetaEntry {
  label: string;
  category: ChaosCategory;
  icon: LucideIcon;
  description: string;
}

export const CHAOS_META: Record<ChaosType, ChaosMetaEntry> = {
  crash: {
    label: 'Instance Crash',
    category: 'Infrastructure Failures',
    icon: ServerCrash,
    description: 'Node goes fully down; all its traffic is dropped.',
  },
  cpuSpike: {
    label: 'VM CPU Spike',
    category: 'Infrastructure Failures',
    icon: Flame,
    description: 'Capacity drops to 30% and latency doubles.',
  },
  diskFailure: {
    label: 'Disk Failure',
    category: 'Infrastructure Failures',
    icon: HardDriveDownload,
    description: 'Capacity drops to 40% and latency triples.',
  },
  instanceSlow: {
    label: 'Instance Slowdown',
    category: 'Infrastructure Failures',
    icon: Snail,
    description: 'Capacity halves and latency grows 4×.',
  },
  memoryLeak: {
    label: 'Memory Pressure',
    category: 'Infrastructure Failures',
    icon: MemoryStick,
    description: 'Capacity halves and latency doubles.',
  },
  packetLoss: {
    label: 'Packet Loss',
    category: 'Network Chaos',
    icon: Filter,
    description: '30% of inbound requests are lost.',
  },
  highLatency: {
    label: 'High Latency',
    category: 'Network Chaos',
    icon: Snail,
    description: 'Base latency increases 5×.',
  },
  partition: {
    label: 'Network Partition',
    category: 'Network Chaos',
    icon: Scissors,
    description: 'Node is unreachable; all traffic is dropped.',
  },
  bandwidthThrottle: {
    label: 'Bandwidth Throttle',
    category: 'Network Chaos',
    icon: Timer,
    description: 'Capacity halves and latency doubles.',
  },
  availabilityZone: {
    label: 'AZ Outage',
    category: 'Infrastructure Failures',
    icon: CloudOff,
    description: 'One availability zone lost: capacity −33%, latency +20%.',
  },
  dataCenter: {
    label: 'Data Center Outage',
    category: 'Infrastructure Failures',
    icon: Building2,
    description: 'Half the fleet lost: capacity −50%, latency +50%.',
  },
  diskCorruption: {
    label: 'Disk Corruption',
    category: 'Infrastructure Failures',
    icon: HardDrive,
    description: 'Capacity −40% and 15% of requests error.',
  },
  storageIops: {
    label: 'Storage IOPS Limit',
    category: 'Infrastructure Failures',
    icon: HardDriveDownload,
    description: 'IO-bound: capacity halves, latency triples.',
  },
  hostHardware: {
    label: 'Host Hardware Fault',
    category: 'Infrastructure Failures',
    icon: Wrench,
    description: 'Capacity halves and latency doubles.',
  },
  crossRegion: {
    label: 'Cross-Region Latency',
    category: 'Network Chaos',
    icon: Globe,
    description: 'Adds large geographic latency (base ×6).',
  },
  connectionFlapping: {
    label: 'Connection Flapping',
    category: 'Network Chaos',
    icon: Unplug,
    description: '20% packet loss and latency doubles.',
  },
  dnsFailure: {
    label: 'DNS Resolution Failure',
    category: 'Network Chaos',
    icon: Router,
    description: 'Resolution fails for 25% of requests; latency +50%.',
  },
  tlsHandshake: {
    label: 'TLS Handshake Issue',
    category: 'Network Chaos',
    icon: Lock,
    description: 'Handshake errors: 10% fail and latency doubles.',
  },
  // ── Application-Level Chaos ─────────────────────────────────────
  memoryLeakApp: {
    label: 'Memory Leak',
    category: 'Application-Level Chaos',
    icon: MemoryStick,
    description: 'Gradual degradation: capacity −40%, latency ×2.5.',
  },
  threadPoolExhaustion: {
    label: 'Thread Pool Exhaustion',
    category: 'Application-Level Chaos',
    icon: CircuitBoard,
    description: 'No free workers: capacity −60% and latency ×3.',
  },
  deadlock: {
    label: 'Deadlock',
    category: 'Application-Level Chaos',
    icon: Skull,
    description: 'Threads stuck: capacity −70%, latency ×4.',
  },
  gcPause: {
    label: 'GC Pause',
    category: 'Application-Level Chaos',
    icon: Hourglass,
    description: 'Stop-the-world pauses spike latency ×3.',
  },
  configDrift: {
    label: 'Configuration Drift',
    category: 'Application-Level Chaos',
    icon: GitFork,
    description: 'Misconfig causes 8% of requests to error.',
  },
  deploymentMisconfig: {
    label: 'Deployment Misconfig',
    category: 'Application-Level Chaos',
    icon: Bug,
    description: 'Bad release: 20% error rate and latency +50%.',
  },
  // ── Data Layer Chaos ────────────────────────────────────────────
  dbPrimaryFailover: {
    label: 'DB Primary Failover',
    category: 'Data Layer Chaos',
    icon: DatabaseBackup,
    description: 'Brief unavailability during failover: capacity −60%, latency ×3.',
  },
  replicaFailure: {
    label: 'Replica Failure',
    category: 'Data Layer Chaos',
    icon: CopyX,
    description: 'Lost read replica: capacity −40%, latency +50%.',
  },
  replicationLag: {
    label: 'Replication Lag',
    category: 'Data Layer Chaos',
    icon: Timer,
    description: 'Stale reads and back-pressure: latency ×2.',
  },
  splitBrain: {
    label: 'Split-Brain',
    category: 'Data Layer Chaos',
    icon: GitFork,
    description: 'Conflicting writes: 15% error and capacity −30%.',
  },
  hotShard: {
    label: 'Hot Shard',
    category: 'Data Layer Chaos',
    icon: Flame,
    description: 'Uneven keys overload one shard: capacity −50%, latency ×2.5.',
  },
  connectionPoolExhaustion: {
    label: 'Connection Pool Exhaustion',
    category: 'Data Layer Chaos',
    icon: Unplug,
    description: 'No DB connections free: capacity −60%, latency ×3.',
  },
  lockContention: {
    label: 'Lock Contention',
    category: 'Data Layer Chaos',
    icon: LockIcon,
    description: 'Row/table locks serialize work: capacity −50%, latency ×2.5.',
  },
  cachePoisoning: {
    label: 'Cache Poisoning',
    category: 'Data Layer Chaos',
    icon: Bug,
    description: 'Bad cached values: 12% of responses error.',
  },
  cacheStampede: {
    label: 'Cache Stampede',
    category: 'Data Layer Chaos',
    icon: TrendingUp,
    description: 'Mass cache miss hammers origin: capacity −50%, latency ×3.',
  },
  // ── Traffic Chaos ───────────────────────────────────────────────
  trafficSpike: {
    label: 'Traffic Spike',
    category: 'Traffic Chaos',
    icon: TrendingUp,
    description: 'Sudden surge: effective capacity −40% from overload.',
  },
  retryStorm: {
    label: 'Retry Storm',
    category: 'Traffic Chaos',
    icon: RefreshCw,
    description: 'Aggressive retries amplify load: capacity −50%, latency ×2.',
  },
  botTraffic: {
    label: 'Bot Traffic',
    category: 'Traffic Chaos',
    icon: Bot,
    description: 'Scrapers consume capacity: 25% dropped before service.',
  },
  thunderingHerd: {
    label: 'Thundering Herd',
    category: 'Traffic Chaos',
    icon: UsersIcon,
    description: 'Synchronized rush: capacity −60%, latency ×3.',
  },
  payloadBloat: {
    label: 'Payload Bloat',
    category: 'Traffic Chaos',
    icon: PackageX,
    description: 'Oversized requests: capacity −30% and latency ×2.',
  },
  // ── Dependency Chaos ────────────────────────────────────────────
  thirdPartyOutage: {
    label: 'Third-Party Outage',
    category: 'Dependency Chaos',
    icon: CloudOff,
    description: 'External API down: 30% error and latency ×2.',
  },
  authOutage: {
    label: 'Auth Provider Outage',
    category: 'Dependency Chaos',
    icon: KeyRound,
    description: 'Cannot authenticate: 40% of requests fail.',
  },
  serviceDiscoveryFailure: {
    label: 'Service Discovery Failure',
    category: 'Dependency Chaos',
    icon: Crosshair,
    description: 'Cannot locate peers: capacity −50%, latency ×2.',
  },
  clockSkew: {
    label: 'Clock Skew',
    category: 'Dependency Chaos',
    icon: Clock,
    description: 'Time drift breaks tokens/ordering: 10% error.',
  },
};

export const CHAOS_CATEGORIES: ChaosCategory[] = [
  'Infrastructure Failures',
  'Network Chaos',
  'Application-Level Chaos',
  'Data Layer Chaos',
  'Traffic Chaos',
  'Dependency Chaos',
];

