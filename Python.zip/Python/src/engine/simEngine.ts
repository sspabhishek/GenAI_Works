import type {
  ChaosEvent,
  ChaosType,
  Design,
  EdgeFlow,
  NodeMetric,
  NodeRole,
  NodeStatus,
  SimResult,
  SimTotals,
} from '../types';
import { NODE_META } from '../types';

/**
 * Steady-state queueing-network solver for one simulation step.
 *
 * Each node is an exact M/M/c service center (c = replicas):
 *   - capacity (mu)  = capacityQps * replicas * availability * chaosMultiplier
 *   - arrival rate λ propagates from sources downstream (relaxation iterations)
 *   - utilization ρ  = λ / mu
 *   - response time  = service time + queue wait, where the wait distribution
 *     comes from the Erlang-C formula (P(wait) = C(c, a)); mean = C/(mu−λ).
 *   - drops          = max(0, λ − mu); errors reduce served traffic.
 *
 * End-to-end latency is composed over the critical (slowest-mean) path by
 * summing per-node mean and variance, then p = mean + z·σ (normal/CLT).
 *
 * Routing rule:
 *   - 'balancer' nodes split their served throughput equally among successors.
 *   - Every other node fans out its served throughput to all successors
 *     (a request that hits an App Server also touches Cache and Database).
 *
 * Chaos mutates a node's effective capacity / latency / loss at runtime.
 */

interface EffectiveNode {
  id: string;
  role: NodeRole;
  mu: number; // effective capacity qps
  baseLatency: number;
  lossFactor: number; // fraction of traffic dropped before service (0..1)
  errorRate: number; // fraction of served traffic that errors (0..1)
  payloadKb: number;
  replicas: number;
  forcedDown: boolean;
}

interface ChaosEffect {
  muMul: number;
  latMul: number;
  lossFactor: number;
  addError: number;
  forcedDown: boolean;
}

function chaosEffect(chaos: ChaosType | undefined): ChaosEffect {
  const base: ChaosEffect = {
    muMul: 1,
    latMul: 1,
    lossFactor: 0,
    addError: 0,
    forcedDown: false,
  };
  switch (chaos) {
    case 'crash':
    case 'partition':
      return { ...base, muMul: 0, forcedDown: true };
    case 'cpuSpike':
      return { ...base, muMul: 0.3, latMul: 2 };
    case 'diskFailure':
      return { ...base, muMul: 0.4, latMul: 3 };
    case 'instanceSlow':
      return { ...base, muMul: 0.5, latMul: 4 };
    case 'memoryLeak':
    case 'hostHardware':
    case 'bandwidthThrottle':
      return { ...base, muMul: 0.5, latMul: 2 };
    case 'availabilityZone':
      return { ...base, muMul: 0.67, latMul: 1.2 };
    case 'dataCenter':
      return { ...base, muMul: 0.5, latMul: 1.5 };
    case 'diskCorruption':
      return { ...base, muMul: 0.6, addError: 0.15 };
    case 'storageIops':
      return { ...base, muMul: 0.5, latMul: 3 };
    case 'highLatency':
      return { ...base, latMul: 5 };
    case 'crossRegion':
      return { ...base, latMul: 6 };
    case 'packetLoss':
      return { ...base, lossFactor: 0.3 };
    case 'connectionFlapping':
      return { ...base, lossFactor: 0.2, latMul: 2 };
    case 'dnsFailure':
      return { ...base, lossFactor: 0.25, latMul: 1.5 };
    case 'tlsHandshake':
      return { ...base, addError: 0.1, latMul: 2 };
    // Application-level
    case 'memoryLeakApp':
      return { ...base, muMul: 0.6, latMul: 2.5 };
    case 'threadPoolExhaustion':
      return { ...base, muMul: 0.4, latMul: 3 };
    case 'deadlock':
      return { ...base, muMul: 0.3, latMul: 4 };
    case 'gcPause':
      return { ...base, latMul: 3 };
    case 'configDrift':
      return { ...base, addError: 0.08 };
    case 'deploymentMisconfig':
      return { ...base, addError: 0.2, latMul: 1.5 };
    // Data layer
    case 'dbPrimaryFailover':
      return { ...base, muMul: 0.4, latMul: 3 };
    case 'replicaFailure':
      return { ...base, muMul: 0.6, latMul: 1.5 };
    case 'replicationLag':
      return { ...base, latMul: 2 };
    case 'splitBrain':
      return { ...base, muMul: 0.7, addError: 0.15 };
    case 'hotShard':
      return { ...base, muMul: 0.5, latMul: 2.5 };
    case 'connectionPoolExhaustion':
      return { ...base, muMul: 0.4, latMul: 3 };
    case 'lockContention':
      return { ...base, muMul: 0.5, latMul: 2.5 };
    case 'cachePoisoning':
      return { ...base, addError: 0.12 };
    case 'cacheStampede':
      return { ...base, muMul: 0.5, latMul: 3 };
    // Traffic
    case 'trafficSpike':
      return { ...base, muMul: 0.6 };
    case 'retryStorm':
      return { ...base, muMul: 0.5, latMul: 2 };
    case 'botTraffic':
      return { ...base, lossFactor: 0.25 };
    case 'thunderingHerd':
      return { ...base, muMul: 0.4, latMul: 3 };
    case 'payloadBloat':
      return { ...base, muMul: 0.7, latMul: 2 };
    // Dependency
    case 'thirdPartyOutage':
      return { ...base, addError: 0.3, latMul: 2 };
    case 'authOutage':
      return { ...base, addError: 0.4 };
    case 'serviceDiscoveryFailure':
      return { ...base, muMul: 0.5, latMul: 2 };
    case 'clockSkew':
      return { ...base, addError: 0.1 };
    default:
      return base;
  }
}

/**
 * Erlang-B blocking probability via the numerically stable recurrence
 *   B(0, a) = 1,  B(k, a) = a·B(k−1) / (k + a·B(k−1))
 * `c` = number of servers (replicas), `a` = offered load in Erlangs (λ/μ_server).
 */
function erlangB(c: number, a: number): number {
  let b = 1;
  for (let k = 1; k <= c; k++) {
    b = (a * b) / (k + a * b);
  }
  return b;
}

/**
 * Erlang-C: probability that an arriving request must queue (wait > 0) in an
 * M/M/c system. Derived from Erlang-B:  C = B / (1 − ρ(1 − B)), ρ = a/c.
 */
function erlangC(c: number, a: number): number {
  const rho = a / c;
  if (rho >= 1) return 1;
  const b = erlangB(c, a);
  const denom = 1 - rho * (1 - b);
  if (denom <= 0) return 1;
  return b / denom;
}

interface QueueResult {
  /** Mean response time (service + queue wait), ms. */
  meanMs: number;
  /** Variance of response time, ms². */
  varMs2: number;
  saturated: boolean;
}

/**
 * Exact M/M/c response-time statistics.
 *
 * - servers c = replicas, total service rate μ_total = effective capacity (qps).
 * - utilization ρ = λ / μ_total, offered load a = c·ρ.
 * - P(wait) = ErlangC(c, a). Queue wait is 0 w.p. (1−C) and Exp(η) w.p. C,
 *   where η = μ_total − λ. Hence  E[Wq] = C/η,  Var[Wq] = C(2−C)/η².
 * - Response time = deterministic service time + queue wait.
 */
function queueStats(
  muTotalQps: number,
  lambdaQps: number,
  replicas: number,
  serviceMs: number,
): QueueResult {
  const c = Math.max(1, Math.round(replicas));
  if (muTotalQps <= 0) {
    return { meanMs: serviceMs * 50, varMs2: (serviceMs * 50) ** 2, saturated: true };
  }
  const rho = lambdaQps / muTotalQps;
  if (rho >= 1 || lambdaQps >= muTotalQps) {
    // Saturated: unbounded queue. Report a large, finite penalty.
    return { meanMs: serviceMs * 50, varMs2: (serviceMs * 50) ** 2, saturated: true };
  }
  if (lambdaQps <= 0) {
    return { meanMs: serviceMs, varMs2: 0, saturated: false };
  }
  const a = c * rho; // offered load in Erlangs
  const C = erlangC(c, a);
  const etaPerSec = muTotalQps - lambdaQps; // requests/sec drained from queue
  const wqMeanMs = (C / etaPerSec) * 1000;
  const wqVarMs2 = ((C * (2 - C)) / (etaPerSec * etaPerSec)) * 1e6;
  return { meanMs: serviceMs + wqMeanMs, varMs2: wqVarMs2, saturated: false };
}

/** Standard-normal quantiles for end-to-end percentile composition (CLT). */
const Z50 = 0;
const Z99 = 2.3263;

export function simulate(
  design: Design,
  trafficQps: number,
  chaos: ChaosEvent[],
): SimResult {
  const { nodes, edges } = design;
  const chaosByNode = new Map<string, ChaosType>();
  for (const c of chaos) chaosByNode.set(c.nodeId, c.type);

  const eff = new Map<string, EffectiveNode>();
  for (const n of nodes) {
    const cfg = n.data.config;
    const availability = Math.min(1, Math.max(0, (cfg.availabilityPct ?? 100) / 100));
    const rawCapacity = cfg.capacityQps * Math.max(0, cfg.replicas) * availability;
    const fx = chaosEffect(chaosByNode.get(n.id));
    eff.set(n.id, {
      id: n.id,
      role: NODE_META[n.data.kind].role,
      mu: rawCapacity * fx.muMul,
      baseLatency: cfg.baseLatencyMs * fx.latMul,
      lossFactor: fx.lossFactor,
      errorRate: Math.min(1, Math.max(0, (cfg.errorRatePct ?? 0) / 100) + fx.addError),
      payloadKb: Math.max(0, cfg.payloadKb ?? 0),
      replicas: Math.max(0, cfg.replicas),
      forcedDown: fx.forcedDown,
    });
  }

  // adjacency
  const successors = new Map<string, string[]>();
  const indeg = new Map<string, number>();
  for (const n of nodes) {
    successors.set(n.id, []);
    indeg.set(n.id, 0);
  }
  for (const e of edges) {
    if (successors.has(e.source) && eff.has(e.target)) {
      successors.get(e.source)!.push(e.target);
      indeg.set(e.target, (indeg.get(e.target) ?? 0) + 1);
    }
  }

  // sources = nodes with no incoming edges (entry points)
  const sources = nodes.filter((n) => (indeg.get(n.id) ?? 0) === 0).map((n) => n.id);
  const perSourceQps = sources.length > 0 ? trafficQps / sources.length : 0;

  // Relaxation: propagate arrival rates. Iterate nodeCount times for DAG convergence.
  const inRate = new Map<string, number>();
  const served = new Map<string, number>();
  for (const n of nodes) {
    inRate.set(n.id, 0);
    served.set(n.id, 0);
  }

  const iterations = Math.max(1, nodes.length + 1);
  for (let it = 0; it < iterations; it++) {
    const nextIn = new Map<string, number>();
    for (const n of nodes) nextIn.set(n.id, 0);
    // external traffic into sources
    for (const s of sources) nextIn.set(s, (nextIn.get(s) ?? 0) + perSourceQps);

    // recompute served from current inRate, then push downstream
    for (const n of nodes) {
      const e = eff.get(n.id)!;
      const lam = inRate.get(n.id) ?? 0;
      const admitted = lam * (1 - e.lossFactor);
      const srv = Math.min(admitted, e.mu) * (1 - e.errorRate);
      served.set(n.id, srv);

      const outs = successors.get(n.id) ?? [];
      if (outs.length === 0) continue;
      if (e.role === 'balancer') {
        const share = srv / outs.length;
        for (const o of outs) nextIn.set(o, (nextIn.get(o) ?? 0) + share);
      } else {
        for (const o of outs) nextIn.set(o, (nextIn.get(o) ?? 0) + srv);
      }
    }
    for (const n of nodes) inRate.set(n.id, nextIn.get(n.id) ?? 0);
  }

  // Final pass: per-node metrics
  const perNode: NodeMetric[] = [];
  let pathLatencyMax = 0;
  // Per-node response-time mean/variance (ms) for exact percentile composition.
  const meanById = new Map<string, number>();
  const varById = new Map<string, number>();

  for (const n of nodes) {
    const e = eff.get(n.id)!;
    const lam = inRate.get(n.id) ?? 0;
    const admitted = lam * (1 - e.lossFactor);
    const capped = Math.min(admitted, e.mu);
    const srv = capped * (1 - e.errorRate);
    const dropped = Math.max(0, lam - srv);
    const rho = e.mu > 0 ? admitted / e.mu : Infinity;

    // Exact M/M/c response-time statistics (Erlang-C).
    const q = queueStats(e.mu, admitted, e.replicas, e.baseLatency);
    const latency = q.meanMs;
    meanById.set(n.id, q.meanMs);
    varById.set(n.id, q.varMs2);

    let status: NodeStatus = 'ok';
    if (e.forcedDown) status = 'down';
    else if (q.saturated || rho >= 0.95 || dropped > 0.5) status = 'degraded';

    perNode.push({
      id: n.id,
      inRateQps: lam,
      servedQps: srv,
      droppedQps: dropped,
      utilization: isFinite(rho) ? rho : 2,
      latencyMs: latency,
      status,
      successRatePct: lam > 0.01 ? (srv / lam) * 100 : 100,
      spof: false,
    });
  }

  // End-to-end latency over the critical (slowest-by-mean) path. We track the
  // sum of per-node means and variances along that path, then compose
  // percentiles via a normal (CLT) approximation: p = mean + z·sqrt(var).
  const memo = new Map<string, { mean: number; var: number }>();
  const visiting = new Set<string>();
  function pathStats(id: string): { mean: number; var: number } {
    if (memo.has(id)) return memo.get(id)!;
    const own = { mean: meanById.get(id) ?? 0, var: varById.get(id) ?? 0 };
    if (visiting.has(id)) return own; // cycle guard
    visiting.add(id);
    const outs = successors.get(id) ?? [];
    let best = { mean: 0, var: 0 };
    for (const o of outs) {
      const d = pathStats(o);
      if (d.mean > best.mean) best = d;
    }
    visiting.delete(id);
    const total = { mean: own.mean + best.mean, var: own.var + best.var };
    memo.set(id, total);
    return total;
  }
  let pathVar = 0;
  for (const s of sources) {
    const ps = pathStats(s);
    if (ps.mean > pathLatencyMax) {
      pathLatencyMax = ps.mean;
      pathVar = ps.var;
    }
  }

  // Single point of failure detection: a load-bearing node with <=1 replica
  // whose removal disconnects some currently-reachable node from all sources.
  const reachableFrom = (skip: string | null): Set<string> => {
    const seen = new Set<string>();
    const stack = sources.filter((s) => s !== skip);
    for (const s of stack) seen.add(s);
    while (stack.length) {
      const cur = stack.pop()!;
      for (const o of successors.get(cur) ?? []) {
        if (o === skip || seen.has(o)) continue;
        seen.add(o);
        stack.push(o);
      }
    }
    return seen;
  };
  const baseReach = reachableFrom(null);
  const metricById = new Map(perNode.map((m) => [m.id, m]));
  for (const n of nodes) {
    const m = metricById.get(n.id);
    const e = eff.get(n.id)!;
    if (!m || e.replicas > 1 || m.inRateQps <= 0.01) continue;
    const without = reachableFrom(n.id);
    let disconnects = false;
    for (const r of baseReach) {
      if (r !== n.id && !without.has(r)) {
        disconnects = true;
        break;
      }
    }
    if (disconnects) m.spof = true;
  }

  // Per-edge flow: distribute each node's served traffic across its out-edges.
  const edgeFlows: EdgeFlow[] = [];
  for (const edge of edges) {
    const src = metricById.get(edge.source);
    if (!src || !eff.has(edge.target)) {
      edgeFlows.push({ id: edge.id, flowQps: 0, health: 'ok' });
      continue;
    }
    const e = eff.get(edge.source)!;
    const outCount = (successors.get(edge.source) ?? []).length || 1;
    const flow = e.role === 'balancer' ? src.servedQps / outCount : src.servedQps;
    edgeFlows.push({ id: edge.id, flowQps: flow, health: src.status });
  }

  // End-to-end success, computed path-aware over the DAG:
  //   success(node) = localServeRatio(node) × downstream(node)
  //   downstream(node) =
  //     • 1                                  if it has no successors (sink)
  //     • weighted AVG of successors         if it is a 'balancer' (a request
  //       takes exactly ONE branch, so average — not product)
  //     • PRODUCT of successors              otherwise (fan-out: the request
  //       fans into calls that must ALL succeed, e.g. cache AND database)
  // completionFraction = traffic-weighted average of success() over sources.
  const localRatio = (id: string): number => {
    const m = metricById.get(id);
    if (!m || m.inRateQps <= 0.01) return 1;
    return Math.max(0, Math.min(1, m.servedQps / m.inRateQps));
  };
  const successMemo = new Map<string, number>();
  const successVisiting = new Set<string>();
  function nodeSuccess(id: string): number {
    if (successMemo.has(id)) return successMemo.get(id)!;
    if (successVisiting.has(id)) return localRatio(id); // cycle guard
    successVisiting.add(id);
    const outs = successors.get(id) ?? [];
    let downstream = 1;
    if (outs.length > 0) {
      const e = eff.get(id);
      if (e?.role === 'balancer') {
        // Equal split → simple average of branch successes.
        let sum = 0;
        for (const o of outs) sum += nodeSuccess(o);
        downstream = sum / outs.length;
      } else {
        for (const o of outs) downstream *= nodeSuccess(o);
      }
    }
    successVisiting.delete(id);
    const result = localRatio(id) * downstream;
    successMemo.set(id, result);
    return result;
  }

  const anyTraffic = perNode.some((m) => m.inRateQps > 0.01);
  let completionFraction = 1;
  if (anyTraffic && sources.length > 0) {
    let sum = 0;
    for (const s of sources) sum += nodeSuccess(s);
    completionFraction = sum / sources.length;
  }

  // Throughput = requests/s that complete the whole system end-to-end.
  const throughput = trafficQps * completionFraction;
  const totalDropped = Math.max(0, trafficQps - throughput);
  const successRatePct = Math.max(0, Math.min(100, completionFraction * 100));
  // Bandwidth: sum of served traffic × payload across every node (MB/s).
  const bandwidthMBs = perNode.reduce((acc, m) => {
    const e = eff.get(m.id)!;
    return acc + (m.servedQps * e.payloadKb) / 1024;
  }, 0);

  // End-to-end percentiles composed from the critical path's mean & variance
  // via a normal (CLT) approximation:  p = mean + z·σ.  p50 = mean (z=0).
  const pathStd = Math.sqrt(Math.max(0, pathVar));
  const p50 = pathLatencyMax + Z50 * pathStd;
  const p99 = pathLatencyMax + Z99 * pathStd;

  const totals: SimTotals = {
    offeredQps: trafficQps,
    throughputQps: throughput,
    droppedQps: totalDropped,
    p50LatencyMs: p50,
    p99LatencyMs: Math.max(p99, p50),
    successRatePct,
    bandwidthMBs,
  };

  return { perNode, edgeFlows, totals };
}
