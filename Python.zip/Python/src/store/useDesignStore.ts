import { create } from 'zustand';
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type EdgeChange,
  type NodeChange,
} from 'reactflow';
import type {
  ChaosEvent,
  ChaosType,
  Design,
  FromWorker,
  SeriesPoint,
  SimEdge,
  SimNode,
  SimResult,
  SimTotals,
  ToWorker,
} from '../types';
import { NODE_META, type NodeKind } from '../types';
import { defaultDesign } from '../lib/defaultDesign';
import { buildPreset } from '../lib/presets';
import {
  createDesign,
  deleteDesign as storageDelete,
  duplicateDesign as storageDuplicate,
  getDesign,
  listDesigns,
  migrateLegacy,
  renameDesign as storageRename,
  updateDesign,
  type StoredDesign,
} from '../lib/storage';

const MAX_SERIES = 60;

let worker: Worker | null = null;
let nodeIdSeq = 1;

function getWorker(): Worker {
  if (!worker) {
    worker = new Worker(new URL('../workers/sim.worker.ts', import.meta.url), {
      type: 'module',
    });
    worker.onmessage = (ev: MessageEvent<FromWorker>) => {
      if (ev.data.type === 'metrics') {
        useStore.getState().applyMetrics(ev.data.result, ev.data.point);
      }
    };
  }
  return worker;
}

function post(msg: ToWorker) {
  getWorker().postMessage(msg);
}

interface State {
  nodes: SimNode[];
  edges: SimEdge[];
  trafficQps: number;
  speed: number;
  running: boolean;
  selectedNodeId: string | null;
  chaos: ChaosEvent[];
  totals: SimTotals | null;
  series: SeriesPoint[];

  /** Id of the currently-loaded saved design, or null if unsaved. */
  currentDesignId: string | null;
  currentDesignName: string;
  /** Whether there are unsaved changes since last save/load. */
  dirty: boolean;
  /** Cached list of saved designs (refreshed on demand). */
  savedDesigns: StoredDesign[];

  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (c: Connection) => void;
  addNode: (kind: NodeKind, position: { x: number; y: number }) => void;
  selectNode: (id: string | null) => void;
  updateNodeConfig: (id: string, patch: Partial<SimNode['data']['config']>) => void;
  renameNode: (id: string, label: string) => void;
  deleteNode: (id: string) => void;
  deleteSelected: () => void;

  setTraffic: (v: number) => void;
  setSpeed: (v: number) => void;
  start: () => void;
  stop: () => void;
  reset: () => void;

  injectChaos: (type: ChaosType) => void;
  clearChaos: () => void;

  applyMetrics: (result: SimResult, point: SeriesPoint) => void;

  // Persistence (local, multi-design)
  refreshDesigns: () => void;
  saveCurrent: () => void;
  saveAs: (name: string) => void;
  loadDesignById: (id: string) => void;
  renameSavedDesign: (id: string, name: string) => void;
  deleteSavedDesign: (id: string) => void;
  duplicateSavedDesign: (id: string) => void;
  newDesign: () => void;
  exportDesign: () => string;
  importDesign: (json: string) => boolean;
  loadPreset: (id?: string) => void;
}

function design(state: Pick<State, 'nodes' | 'edges'>): Design {
  return { nodes: state.nodes, edges: state.edges };
}

function syncDesign(get: () => State) {
  post({ type: 'init', design: design(get()) });
}

/** Ensure all edges use the animated 'flow' renderer. */
function asFlowEdges(edges: SimEdge[]): SimEdge[] {
  return edges.map((e) => ({ ...e, type: 'flow' as const }));
}

export const useStore = create<State>((set, get) => ({
  nodes: defaultDesign().nodes,
  edges: defaultDesign().edges,
  trafficQps: 1000,
  speed: 1,
  running: false,
  selectedNodeId: null,
  chaos: [],
  totals: null,
  series: [],

  currentDesignId: null,
  currentDesignName: 'Untitled design',
  dirty: false,
  savedDesigns: [],

  onNodesChange: (changes) => {
    set({ nodes: applyNodeChanges(changes, get().nodes) as SimNode[] });
    if (changes.some((c) => c.type === 'remove')) {
      const removed = new Set(
        changes.filter((c) => c.type === 'remove').map((c) => (c as { id: string }).id),
      );
      set({
        chaos: get().chaos.filter((ch) => !removed.has(ch.nodeId)),
        selectedNodeId: removed.has(get().selectedNodeId ?? '')
          ? null
          : get().selectedNodeId,
      });
      syncDesign(get);
    }
  },
  onEdgesChange: (changes) => {
    set({ edges: applyEdgeChanges(changes, get().edges), dirty: true });
    syncDesign(get);
  },
  onConnect: (c) => {
    set({ edges: addEdge({ ...c, type: 'flow', animated: false }, get().edges), dirty: true });
    syncDesign(get);
  },

  addNode: (kind, position) => {
    const meta = NODE_META[kind];
    const id = `${kind}-${nodeIdSeq++}`;
    const node: SimNode = {
      id,
      type: 'sim',
      position,
      data: {
        label: meta.title,
        kind,
        config: { ...meta.defaults },
      },
    };
    set({ nodes: [...get().nodes, node], dirty: true });
    syncDesign(get);
  },

  selectNode: (id) => set({ selectedNodeId: id }),

  deleteNode: (id) => {
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
      chaos: get().chaos.filter((c) => c.nodeId !== id),
      selectedNodeId: get().selectedNodeId === id ? null : get().selectedNodeId,
      dirty: true,
    });
    syncDesign(get);
  },

  deleteSelected: () => {
    const id = get().selectedNodeId;
    if (id) get().deleteNode(id);
  },

  updateNodeConfig: (id, patch) => {
    set({
      nodes: get().nodes.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, config: { ...n.data.config, ...patch } } } : n,
      ),
      dirty: true,
    });
    syncDesign(get);
  },

  renameNode: (id, label) => {
    set({
      nodes: get().nodes.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, label } } : n,
      ),
      dirty: true,
    });
    syncDesign(get);
  },

  setTraffic: (v) => {
    set({ trafficQps: v });
    post({ type: 'params', trafficQps: v, speed: get().speed });
  },
  setSpeed: (v) => {
    set({ speed: v });
    post({ type: 'params', trafficQps: get().trafficQps, speed: v });
  },

  start: () => {
    syncDesign(get);
    post({ type: 'params', trafficQps: get().trafficQps, speed: get().speed });
    post({ type: 'start' });
    set({ running: true });
  },
  stop: () => {
    post({ type: 'stop' });
    set({
      running: false,
      // Clear live flow so animated traffic dots stop immediately.
      edges: get().edges.map((e) => ({
        ...e,
        data: { ...e.data, flowQps: 0 },
      })),
    });
  },
  reset: () => {
    post({ type: 'stop' });
    post({ type: 'clearChaos' });
    set({
      running: false,
      chaos: [],
      totals: null,
      series: [],
      nodes: get().nodes.map((n) => ({
        ...n,
        data: {
          ...n.data,
          utilization: undefined,
          status: undefined,
          inRateQps: undefined,
          servedQps: undefined,
          droppedQps: undefined,
          latencyMs: undefined,
          successRatePct: undefined,
          spof: undefined,
        },
      })),
      edges: get().edges.map((e) => ({
        ...e,
        animated: false,
        data: { ...e.data, flowQps: 0, health: 'ok' as const },
      })),
    });
  },

  injectChaos: (type) => {
    const id = get().selectedNodeId;
    if (!id) return;
    const event: ChaosEvent = { nodeId: id, type };
    set({ chaos: [...get().chaos.filter((c) => c.nodeId !== id), event] });
    post({ type: 'chaos', event });
  },
  clearChaos: () => {
    set({ chaos: [] });
    post({ type: 'clearChaos' });
  },

  applyMetrics: (result, point) => {
    // Ignore late worker messages that arrive after the user pressed stop.
    if (!get().running) return;
    const byId = new Map(result.perNode.map((m) => [m.id, m]));
    const flowById = new Map(result.edgeFlows.map((f) => [f.id, f]));
    set({
      totals: result.totals,
      series: [...get().series, point].slice(-MAX_SERIES),
      nodes: get().nodes.map((n) => {
        const m = byId.get(n.id);
        if (!m) return n;
        return {
          ...n,
          data: {
            ...n.data,
            utilization: m.utilization,
            status: m.status,
            inRateQps: m.inRateQps,
            servedQps: m.servedQps,
            droppedQps: m.droppedQps,
            latencyMs: m.latencyMs,
            successRatePct: m.successRatePct,
            spof: m.spof,
          },
        };
      }),
      edges: get().edges.map((e) => {
        const f = flowById.get(e.id);
        return {
          ...e,
          type: 'flow',
          data: { ...e.data, flowQps: f?.flowQps ?? 0, health: f?.health ?? 'ok' },
        };
      }),
    });
  },

  save: () => {
    get().saveCurrent();
  },
  load: () => {
    const list = listDesigns();
    if (list[0]) get().loadDesignById(list[0].id);
  },

  refreshDesigns: () => {
    set({ savedDesigns: listDesigns() });
  },

  saveCurrent: () => {
    const id = get().currentDesignId;
    const d = design(get());
    if (id && getDesign(id)) {
      updateDesign(id, d);
      set({ dirty: false, savedDesigns: listDesigns() });
    } else {
      const rec = createDesign(get().currentDesignName || 'Untitled design', d);
      set({
        currentDesignId: rec.id,
        currentDesignName: rec.name,
        dirty: false,
        savedDesigns: listDesigns(),
      });
    }
  },

  saveAs: (name) => {
    const rec = createDesign(name.trim() || 'Untitled design', design(get()));
    set({
      currentDesignId: rec.id,
      currentDesignName: rec.name,
      dirty: false,
      savedDesigns: listDesigns(),
    });
  },

  loadDesignById: (id) => {
    const rec = getDesign(id);
    if (!rec) return;
    set({
      nodes: rec.design.nodes,
      edges: asFlowEdges(rec.design.edges),
      currentDesignId: rec.id,
      currentDesignName: rec.name,
      dirty: false,
      selectedNodeId: null,
      totals: null,
      series: [],
      chaos: [],
      running: false,
    });
    post({ type: 'stop' });
    post({ type: 'clearChaos' });
    syncDesign(get);
  },

  renameSavedDesign: (id, name) => {
    storageRename(id, name.trim() || 'Untitled design');
    set({
      savedDesigns: listDesigns(),
      currentDesignName: get().currentDesignId === id ? name.trim() : get().currentDesignName,
    });
  },

  deleteSavedDesign: (id) => {
    storageDelete(id);
    const clearCurrent = get().currentDesignId === id;
    set({
      savedDesigns: listDesigns(),
      currentDesignId: clearCurrent ? null : get().currentDesignId,
      dirty: clearCurrent ? true : get().dirty,
    });
  },

  duplicateSavedDesign: (id) => {
    storageDuplicate(id);
    set({ savedDesigns: listDesigns() });
  },

  newDesign: () => {
    const d = defaultDesign();
    set({
      nodes: d.nodes,
      edges: asFlowEdges(d.edges),
      currentDesignId: null,
      currentDesignName: 'Untitled design',
      dirty: false,
      selectedNodeId: null,
      totals: null,
      series: [],
      chaos: [],
      running: false,
    });
    post({ type: 'stop' });
    post({ type: 'clearChaos' });
    syncDesign(get);
  },

  exportDesign: () => {
    return JSON.stringify(
      { name: get().currentDesignName, ...design(get()) },
      null,
      2,
    );
  },

  importDesign: (json) => {
    try {
      const parsed = JSON.parse(json) as Partial<Design> & { name?: string };
      if (!Array.isArray(parsed.nodes) || !Array.isArray(parsed.edges)) return false;
      set({
        nodes: parsed.nodes,
        edges: asFlowEdges(parsed.edges),
        currentDesignId: null,
        currentDesignName: parsed.name?.trim() || 'Imported design',
        dirty: true,
        selectedNodeId: null,
        totals: null,
        series: [],
        chaos: [],
        running: false,
      });
      post({ type: 'stop' });
      post({ type: 'clearChaos' });
      syncDesign(get);
      return true;
    } catch {
      return false;
    }
  },

  loadPreset: (id?: string) => {
    const d = id ? buildPreset(id) : defaultDesign();
    set({
      nodes: d.nodes,
      edges: asFlowEdges(d.edges),
      currentDesignId: null,
      currentDesignName: id ? `${id} preset` : 'Untitled design',
      dirty: true,
      selectedNodeId: null,
      totals: null,
      series: [],
      chaos: [],
      running: false,
    });
    post({ type: 'stop' });
    post({ type: 'clearChaos' });
    syncDesign(get);
  },
}));

// Migrate any legacy single-slot save and prime the designs list.
migrateLegacy();
useStore.getState().refreshDesigns();
