import type { Design } from '../types';

/** A design saved in the browser, with metadata. */
export interface StoredDesign {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  design: Design;
}

const INDEX_KEY = 'sds.designs.v1';
/** Legacy single-slot key from earlier versions. */
const LEGACY_KEY = 'sds.design.v1';

function readIndex(): StoredDesign[] {
  try {
    const raw = localStorage.getItem(INDEX_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as StoredDesign[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeIndex(designs: StoredDesign[]): void {
  localStorage.setItem(INDEX_KEY, JSON.stringify(designs));
}

function newId(): string {
  return `d_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

/** Returns all saved designs, most-recently-updated first. */
export function listDesigns(): StoredDesign[] {
  return readIndex().sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getDesign(id: string): StoredDesign | undefined {
  return readIndex().find((d) => d.id === id);
}

/** Create a new saved design; returns its record. */
export function createDesign(name: string, design: Design): StoredDesign {
  const now = Date.now();
  const record: StoredDesign = { id: newId(), name, createdAt: now, updatedAt: now, design };
  const all = readIndex();
  all.push(record);
  writeIndex(all);
  return record;
}

/** Overwrite an existing design's graph (and bump updatedAt). */
export function updateDesign(id: string, design: Design): StoredDesign | undefined {
  const all = readIndex();
  const idx = all.findIndex((d) => d.id === id);
  if (idx === -1) return undefined;
  all[idx] = { ...all[idx], design, updatedAt: Date.now() };
  writeIndex(all);
  return all[idx];
}

export function renameDesign(id: string, name: string): void {
  const all = readIndex();
  const idx = all.findIndex((d) => d.id === id);
  if (idx === -1) return;
  all[idx] = { ...all[idx], name, updatedAt: Date.now() };
  writeIndex(all);
}

export function deleteDesign(id: string): void {
  writeIndex(readIndex().filter((d) => d.id !== id));
}

export function duplicateDesign(id: string): StoredDesign | undefined {
  const src = getDesign(id);
  if (!src) return undefined;
  return createDesign(`${src.name} (copy)`, src.design);
}

/** One-time migration of the legacy single-slot save into the index. */
export function migrateLegacy(): void {
  try {
    const raw = localStorage.getItem(LEGACY_KEY);
    if (!raw) return;
    const design = JSON.parse(raw) as Design;
    if (design?.nodes) createDesign('Imported design', design);
    localStorage.removeItem(LEGACY_KEY);
  } catch {
    /* ignore */
  }
}
