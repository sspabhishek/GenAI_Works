import type { Design, NodeKind, SimEdge, SimNode } from '../types';
import { NODE_META } from '../types';

let seq = 1;

function node(
  id: string,
  kind: NodeKind,
  x: number,
  y: number,
  label?: string,
): SimNode {
  return {
    id,
    type: 'sim',
    position: { x, y },
    data: {
      label: label ?? NODE_META[kind].title,
      kind,
      config: { ...NODE_META[kind].defaults },
    },
  };
}

function edge(source: string, target: string): SimEdge {
  return { id: `e${seq++}`, source, target, type: 'flow' };
}

export interface PresetDef {
  id: string;
  name: string;
  description: string;
  build: () => Design;
}

export const PRESETS: PresetDef[] = [
  {
    id: 'basic-web',
    name: 'Basic Web App',
    description: 'Gateway → LB → service → cache + database.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', 0, 160, 'api gateway'),
        node('lb', 'loadBalancer', 240, 160, 'load balancer'),
        node('app', 'appServer', 480, 160, 'generic service'),
        node('cache', 'cache', 760, 40, 'redis'),
        node('db', 'database', 760, 280, 'postgres'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'app'),
        edge('app', 'cache'),
        edge('app', 'db'),
      ],
    }),
  },
  {
    id: 'edge-cdn',
    name: 'Edge + CDN',
    description: 'DNS → CDN → WAF → gateway → service → storage.',
    build: () => ({
      nodes: [
        node('dns', 'dns', 0, 160),
        node('cdn', 'cdn', 220, 160),
        node('waf', 'firewall', 440, 160),
        node('gw', 'apiGateway', 660, 160, 'api gateway'),
        node('app', 'appServer', 880, 160, 'web service'),
        node('obj', 'objectStorage', 1120, 160, 'assets'),
      ],
      edges: [
        edge('dns', 'cdn'),
        edge('cdn', 'waf'),
        edge('waf', 'gw'),
        edge('gw', 'app'),
        edge('app', 'obj'),
      ],
    }),
  },
  {
    id: 'microservices',
    name: 'Microservices',
    description: 'Gateway → LB → auth + two services → DB & cache.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', 0, 200, 'api gateway'),
        node('lb', 'loadBalancer', 220, 200, 'load balancer'),
        node('auth', 'authService', 440, 40, 'auth'),
        node('svcA', 'appServer', 440, 200, 'orders svc'),
        node('svcB', 'appServer', 440, 360, 'users svc'),
        node('cache', 'cache', 700, 100, 'redis'),
        node('db', 'database', 700, 300, 'postgres'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'auth'),
        edge('lb', 'svcA'),
        edge('lb', 'svcB'),
        edge('svcA', 'cache'),
        edge('svcA', 'db'),
        edge('svcB', 'db'),
      ],
    }),
  },
  {
    id: 'event-driven',
    name: 'Event-Driven',
    description: 'Gateway → service → queue → worker → database.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', 0, 160, 'api gateway'),
        node('app', 'appServer', 240, 160, 'ingest svc'),
        node('mq', 'messageQueue', 480, 160, 'kafka'),
        node('worker', 'worker', 720, 160, 'worker'),
        node('db', 'database', 960, 160, 'postgres'),
      ],
      edges: [
        edge('gw', 'app'),
        edge('app', 'mq'),
        edge('mq', 'worker'),
        edge('worker', 'db'),
      ],
    }),
  },
  {
    id: 'search-stack',
    name: 'Search Stack',
    description: 'Gateway → LB → service → search index + database.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', 0, 160, 'api gateway'),
        node('lb', 'loadBalancer', 220, 160, 'load balancer'),
        node('app', 'appServer', 440, 160, 'search api'),
        node('idx', 'searchIndex', 700, 60, 'elastic'),
        node('db', 'database', 700, 280, 'postgres'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'app'),
        edge('app', 'idx'),
        edge('app', 'db'),
      ],
    }),
  },
  {
    id: 'url-shortener',
    name: 'URL Shortener (TinyURL)',
    description: 'FAANG classic: read-heavy, cache-first short links with a KV store.',
    build: () => ({
      nodes: [
        node('cdn', 'cdn', -240, 180, 'cdn'),
        node('gw', 'apiGateway', 0, 180, 'api gateway'),
        node('rl', 'rateLimiter', 220, 180, 'rate limiter'),
        node('lb', 'loadBalancer', 440, 180, 'load balancer'),
        node('app', 'appServer', 660, 180, 'redirect svc'),
        node('cache', 'cache', 900, 60, 'redis (hot links)'),
        node('kv', 'kvStore', 900, 300, 'dynamo (id→url)'),
      ],
      edges: [
        edge('cdn', 'gw'),
        edge('gw', 'rl'),
        edge('rl', 'lb'),
        edge('lb', 'app'),
        edge('app', 'cache'),
        edge('app', 'kv'),
      ],
    }),
  },
  {
    id: 'video-streaming',
    name: 'Video Streaming (Netflix/YouTube)',
    description: 'CDN-heavy delivery with upload, async transcoding, and metadata.',
    build: () => ({
      nodes: [
        node('dns', 'dns', -260, 220, 'dns (geo)'),
        node('cdn', 'cdn', -40, 220, 'cdn (video)'),
        node('gw', 'apiGateway', 200, 220, 'api gateway'),
        node('lb', 'loadBalancer', 420, 220, 'load balancer'),
        node('play', 'appServer', 640, 120, 'playback svc'),
        node('upload', 'appServer', 640, 340, 'upload svc'),
        node('meta', 'database', 900, 60, 'metadata db'),
        node('cache', 'cache', 900, 200, 'metadata cache'),
        node('queue', 'messageQueue', 900, 340, 'transcode queue'),
        node('transcode', 'mediaProcessor', 1160, 340, 'transcoder'),
        node('obj', 'objectStorage', 1400, 240, 's3 (segments)'),
      ],
      edges: [
        edge('dns', 'cdn'),
        edge('cdn', 'gw'),
        edge('gw', 'lb'),
        edge('lb', 'play'),
        edge('lb', 'upload'),
        edge('play', 'meta'),
        edge('play', 'cache'),
        edge('upload', 'queue'),
        edge('queue', 'transcode'),
        edge('transcode', 'obj'),
      ],
    }),
  },
  {
    id: 'social-feed',
    name: 'Social Feed (Twitter/Instagram)',
    description: 'Fan-out-on-write timeline with a social graph and feed cache.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', -40, 220, 'api gateway'),
        node('lb', 'loadBalancer', 180, 220, 'load balancer'),
        node('tweet', 'appServer', 400, 100, 'post svc'),
        node('timeline', 'appServer', 400, 360, 'timeline svc'),
        node('graph', 'graphDb', 660, 40, 'social graph'),
        node('stream', 'eventStream', 660, 180, 'kafka (posts)'),
        node('fanout', 'worker', 900, 180, 'fan-out worker'),
        node('feedcache', 'cache', 1140, 120, 'feed cache'),
        node('db', 'database', 660, 360, 'post store'),
        node('media', 'objectStorage', 400, 520, 'media store'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'tweet'),
        edge('lb', 'timeline'),
        edge('tweet', 'db'),
        edge('tweet', 'stream'),
        edge('tweet', 'media'),
        edge('stream', 'fanout'),
        edge('fanout', 'feedcache'),
        edge('timeline', 'feedcache'),
        edge('timeline', 'graph'),
      ],
    }),
  },
  {
    id: 'rideshare',
    name: 'Ride Sharing (Uber/Lyft)',
    description: 'Real-time matching with a geo index, GPS stream, and surge pricing.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', -60, 240, 'api gateway'),
        node('lb', 'loadBalancer', 160, 240, 'load balancer'),
        node('location', 'appServer', 380, 80, 'location svc'),
        node('match', 'appServer', 380, 240, 'matching svc'),
        node('pricing', 'appServer', 380, 420, 'pricing svc'),
        node('stream', 'eventStream', 640, 80, 'gps stream'),
        node('geo', 'kvStore', 640, 220, 'geo index'),
        node('trip', 'database', 640, 360, 'trip db'),
        node('notify', 'notificationService', 900, 240, 'driver push'),
        node('surge', 'cache', 640, 520, 'surge cache'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'location'),
        edge('lb', 'match'),
        edge('lb', 'pricing'),
        edge('location', 'stream'),
        edge('stream', 'geo'),
        edge('match', 'geo'),
        edge('match', 'trip'),
        edge('match', 'notify'),
        edge('pricing', 'surge'),
      ],
    }),
  },
  {
    id: 'chat',
    name: 'Chat / Messaging (WhatsApp)',
    description: 'Realtime delivery with presence, pub/sub fan-out, and history.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', -40, 220, 'ws gateway'),
        node('lb', 'loadBalancer', 180, 220, 'load balancer'),
        node('msg', 'appServer', 400, 120, 'message svc'),
        node('presence', 'appServer', 400, 360, 'presence svc'),
        node('pubsub', 'pubsub', 660, 120, 'pub/sub'),
        node('queue', 'messageQueue', 660, 260, 'delivery queue'),
        node('history', 'database', 900, 120, 'message history'),
        node('presenceCache', 'cache', 660, 420, 'presence cache'),
        node('push', 'notificationService', 900, 280, 'push svc'),
      ],
      edges: [
        edge('gw', 'lb'),
        edge('lb', 'msg'),
        edge('lb', 'presence'),
        edge('msg', 'pubsub'),
        edge('msg', 'queue'),
        edge('msg', 'history'),
        edge('queue', 'push'),
        edge('presence', 'presenceCache'),
      ],
    }),
  },
  {
    id: 'ecommerce',
    name: 'E-Commerce Checkout (Amazon)',
    description: 'Cart, inventory, payments with fraud check, and async fulfillment.',
    build: () => ({
      nodes: [
        node('cdn', 'cdn', -300, 260, 'cdn'),
        node('gw', 'apiGateway', -80, 260, 'api gateway'),
        node('lb', 'loadBalancer', 140, 260, 'load balancer'),
        node('cart', 'appServer', 360, 80, 'cart svc'),
        node('order', 'appServer', 360, 260, 'order svc'),
        node('payment', 'appServer', 360, 440, 'payment svc'),
        node('cartcache', 'cache', 620, 60, 'cart cache'),
        node('inventory', 'database', 620, 220, 'inventory db'),
        node('fraud', 'fraudDetection', 620, 400, 'fraud check'),
        node('queue', 'messageQueue', 620, 560, 'order events'),
        node('fulfill', 'worker', 900, 560, 'fulfillment'),
      ],
      edges: [
        edge('cdn', 'gw'),
        edge('gw', 'lb'),
        edge('lb', 'cart'),
        edge('lb', 'order'),
        edge('lb', 'payment'),
        edge('cart', 'cartcache'),
        edge('order', 'inventory'),
        edge('order', 'queue'),
        edge('payment', 'fraud'),
        edge('queue', 'fulfill'),
      ],
    }),
  },
  {
    id: 'rag-ai',
    name: 'AI RAG Platform (LLM)',
    description: 'Retrieval-augmented generation: embeddings, vector search, LLM gateway.',
    build: () => ({
      nodes: [
        node('gw', 'apiGateway', -40, 200, 'api gateway'),
        node('rl', 'rateLimiter', 180, 200, 'rate limiter'),
        node('orch', 'agentOrchestrator', 400, 200, 'orchestrator'),
        node('embed', 'appServer', 640, 60, 'embedding svc'),
        node('vector', 'vectorDb', 900, 60, 'vector db'),
        node('llm', 'llmGateway', 640, 240, 'llm gateway'),
        node('tools', 'toolRegistry', 640, 400, 'tool registry'),
        node('cache', 'cache', 900, 240, 'response cache'),
      ],
      edges: [
        edge('gw', 'rl'),
        edge('rl', 'orch'),
        edge('orch', 'embed'),
        edge('embed', 'vector'),
        edge('orch', 'llm'),
        edge('orch', 'tools'),
        edge('llm', 'cache'),
      ],
    }),
  },
];

export function buildPreset(id: string): Design {
  const p = PRESETS.find((x) => x.id === id) ?? PRESETS[0];
  return p.build();
}
