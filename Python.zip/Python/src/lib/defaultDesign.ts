import type { Design, SimNode } from '../types';
import { NODE_META } from '../types';

/** The reference layout: gateway -> LB -> app server -> cache + database. */
export function defaultDesign(): Design {
  const mk = (
    id: string,
    kind: SimNode['data']['kind'],
    x: number,
    y: number,
    label?: string,
  ): SimNode => ({
    id,
    type: 'sim',
    position: { x, y },
    data: {
      label: label ?? NODE_META[kind].title,
      kind,
      config: { ...NODE_META[kind].defaults },
    },
  });

  const nodes: SimNode[] = [
    mk('gateway', 'apiGateway', 0, 160, 'api gateway'),
    mk('lb', 'loadBalancer', 240, 160, 'load balancer'),
    mk('app', 'appServer', 480, 160, 'generic service'),
    mk('cache', 'cache', 760, 40, 'redis'),
    mk('db', 'database', 760, 280, 'postgres'),
  ];

  const edges = [
    { id: 'e1', source: 'gateway', target: 'lb', type: 'flow' },
    { id: 'e2', source: 'lb', target: 'app', type: 'flow' },
    { id: 'e3', source: 'app', target: 'cache', type: 'flow' },
    { id: 'e4', source: 'app', target: 'db', type: 'flow' },
  ];

  return { nodes, edges };
}
