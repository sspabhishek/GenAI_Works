import { Canvas } from './canvas/Canvas';
import { Toolbar } from './components/Toolbar';
import { TopMetricsBar } from './components/TopMetricsBar';
import { LeftPanel } from './components/LeftPanel';
import { Inspector } from './components/Inspector';
import { BottomBar } from './components/BottomBar';
import { MetricsPanel } from './components/MetricsPanel';

function App() {
  return (
    <div className="h-full flex flex-col bg-canvas text-gray-200">
      <Toolbar />
      <TopMetricsBar />
      <div className="flex-1 flex min-h-0">
        <LeftPanel />
        <main className="relative flex-1 min-w-0">
          <Canvas />
        </main>
        <aside className="w-72 shrink-0 border-l border-edge bg-panel flex flex-col overflow-y-auto">
          <Inspector />
          <MetricsPanel />
        </aside>
      </div>
      <BottomBar />
    </div>
  );
}

export default App;
