/// <reference lib="webworker" />
import { simulate } from '../engine/simEngine';
import type {
  ChaosEvent,
  Design,
  FromWorker,
  SeriesPoint,
  ToWorker,
} from '../types';

let design: Design = { nodes: [], edges: [] };
let trafficQps = 1000;
let speed = 1;
let chaos: ChaosEvent[] = [];
let timer: ReturnType<typeof setInterval> | null = null;
let t = 0;

const BASE_INTERVAL_MS = 400;

function post(msg: FromWorker) {
  (self as unknown as DedicatedWorkerGlobalScope).postMessage(msg);
}

function step() {
  const result = simulate(design, trafficQps, chaos);
  t += 1;
  const point: SeriesPoint = {
    t,
    throughput: Math.round(result.totals.throughputQps),
    p99: Math.round(result.totals.p99LatencyMs),
    dropped: Math.round(result.totals.droppedQps),
    success: Math.round(result.totals.successRatePct * 100) / 100,
  };
  post({ type: 'metrics', result, point });
}

function restartTimer() {
  if (timer) clearInterval(timer);
  const interval = Math.max(60, BASE_INTERVAL_MS / Math.max(0.1, speed));
  timer = setInterval(step, interval);
}

self.onmessage = (ev: MessageEvent<ToWorker>) => {
  const msg = ev.data;
  switch (msg.type) {
    case 'init':
      design = msg.design;
      break;
    case 'params':
      trafficQps = msg.trafficQps;
      speed = msg.speed;
      if (timer) restartTimer();
      break;
    case 'start':
      t = 0;
      step();
      restartTimer();
      break;
    case 'stop':
      if (timer) clearInterval(timer);
      timer = null;
      break;
    case 'chaos':
      chaos = [...chaos.filter((c) => c.nodeId !== msg.event.nodeId), msg.event];
      break;
    case 'clearChaos':
      chaos = [];
      break;
  }
};
