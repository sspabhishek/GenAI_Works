import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useStore } from '../store/useDesignStore';

function Stat({ label, value, unit, tone }: { label: string; value: string; unit?: string; tone?: string }) {
  return (
    <div className="bg-panel2 rounded-lg px-3 py-2">
      <div className="text-[10px] uppercase tracking-wider text-gray-400">{label}</div>
      <div className="text-lg font-mono" style={{ color: tone ?? '#e5e7eb' }}>
        {value}
        {unit && <span className="text-xs text-gray-500 ml-1">{unit}</span>}
      </div>
    </div>
  );
}

export function MetricsPanel() {
  const totals = useStore((s) => s.totals);
  const series = useStore((s) => s.series);

  return (
    <div className="p-3 border-b border-edge">
      <div className="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-2">
        Live Metrics
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Stat
          label="Throughput"
          value={Math.round(totals?.throughputQps ?? 0).toLocaleString()}
          unit="qps"
          tone="#22c55e"
        />
        <Stat
          label="Dropped"
          value={Math.round(totals?.droppedQps ?? 0).toLocaleString()}
          unit="qps"
          tone={(totals?.droppedQps ?? 0) > 0.5 ? '#ef4444' : undefined}
        />
        <Stat label="p50" value={Math.round(totals?.p50LatencyMs ?? 0).toLocaleString()} unit="ms" />
        <Stat
          label="p99"
          value={Math.round(totals?.p99LatencyMs ?? 0).toLocaleString()}
          unit="ms"
          tone={(totals?.p99LatencyMs ?? 0) > 500 ? '#f59e0b' : undefined}
        />
      </div>

      <div className="mt-3 h-28">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={series} margin={{ top: 6, right: 4, left: -24, bottom: 0 }}>
            <XAxis dataKey="t" hide />
            <YAxis tick={{ fontSize: 9, fill: '#6b7280' }} width={36} />
            <Tooltip
              contentStyle={{
                background: '#11161f',
                border: '1px solid #2a3344',
                borderRadius: 8,
                fontSize: 11,
              }}
            />
            <Line type="monotone" dataKey="throughput" stroke="#22c55e" dot={false} strokeWidth={2} />
            <Line type="monotone" dataKey="dropped" stroke="#ef4444" dot={false} strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="flex gap-3 text-[10px] text-gray-400 mt-1">
        <span className="flex items-center gap-1">
          <span className="w-2 h-0.5 bg-ok inline-block" /> throughput
        </span>
        <span className="flex items-center gap-1">
          <span className="w-2 h-0.5 bg-bad inline-block" /> dropped
        </span>
      </div>
    </div>
  );
}
