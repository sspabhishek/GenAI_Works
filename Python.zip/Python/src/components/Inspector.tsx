import { AlertTriangle, Minus, Plus, Settings, Trash2, X } from 'lucide-react';
import { useStore } from '../store/useDesignStore';
import { AVAILABILITY_TIERS, CHAOS_META, NODE_META } from '../types';

function Stepper({
  label,
  value,
  step,
  min,
  onChange,
  format,
}: {
  label: string;
  value: number;
  step: number;
  min: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[12px] text-gray-300">{label}</span>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onChange(Math.max(min, value - step))}
          className="w-7 h-7 rounded-md bg-panel2 hover:bg-[#1d2536] text-gray-300 flex items-center justify-center"
        >
          <Minus size={14} />
        </button>
        <span className="w-16 text-center font-mono text-sm text-gray-100">
          {format ? format(value) : value}
        </span>
        <button
          onClick={() => onChange(value + step)}
          className="w-7 h-7 rounded-md bg-panel2 hover:bg-[#1d2536] text-gray-300 flex items-center justify-center"
        >
          <Plus size={14} />
        </button>
      </div>
    </div>
  );
}

function fmtCapacity(v: number): string {
  if (v >= 1000) return `${(v / 1000).toFixed(1)}K`;
  return `${v}`;
}

export function Inspector() {
  const nodes = useStore((s) => s.nodes);
  const selectedId = useStore((s) => s.selectedNodeId);
  const updateNodeConfig = useStore((s) => s.updateNodeConfig);
  const renameNode = useStore((s) => s.renameNode);
  const deleteNode = useStore((s) => s.deleteNode);
  const selectNode = useStore((s) => s.selectNode);
  const chaos = useStore((s) => s.chaos);

  const selected = nodes.find((n) => n.id === selectedId) ?? null;

  if (!selected) {
    return (
      <div className="p-3 border-b border-edge">
        <div className="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">
          Component Settings
        </div>
        <div className="text-xs text-gray-500">
          Select a component to edit it. Drag components from the left onto the canvas.
          Hover a node and click the delete icon — or press Delete — to remove it.
        </div>
      </div>
    );
  }

  const meta = NODE_META[selected.data.kind];
  const Icon = meta.icon;
  const cfg = selected.data.config;
  const activeChaos = chaos.filter((c) => c.nodeId === selected.id);
  const totalCapacity = cfg.capacityQps * cfg.replicas;
  const capStep = cfg.capacityQps >= 1000 ? 500 : 100;

  return (
    <div className="border-b border-edge">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-edge">
        <div className="flex items-center gap-2">
          <Settings size={15} className="text-gray-400" />
          <span className="text-sm font-semibold text-gray-100">Component Settings</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            title="Delete component"
            onClick={() => deleteNode(selected.id)}
            className="w-7 h-7 rounded-md hover:bg-bad/20 text-bad flex items-center justify-center"
          >
            <Trash2 size={15} />
          </button>
          <button
            title="Close"
            onClick={() => selectNode(null)}
            className="w-7 h-7 rounded-md hover:bg-panel2 text-gray-400 flex items-center justify-center"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      <div className="p-3 space-y-3">
        <div className="flex items-center gap-2">
          <Icon size={22} strokeWidth={2} style={{ color: meta.color }} />
          <input
            value={selected.data.label}
            onChange={(e) => renameNode(selected.id, e.target.value)}
            className="flex-1 bg-transparent text-lg font-medium text-gray-100 outline-none"
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="text-[12px] text-gray-300">{meta.title}</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-panel2 text-gray-400 uppercase tracking-wider">
            {meta.category}
          </span>
        </div>

        <div className="h-px bg-edge" />
        <div className="text-[10px] font-semibold uppercase tracking-wider text-gray-500">
          Component Settings
        </div>

        <Stepper
          label="Replicas / Instances"
          value={cfg.replicas}
          step={1}
          min={0}
          onChange={(v) => updateNodeConfig(selected.id, { replicas: v })}
        />
        <Stepper
          label="Node Capacity (RPS)"
          value={cfg.capacityQps}
          step={capStep}
          min={1}
          format={fmtCapacity}
          onChange={(v) => updateNodeConfig(selected.id, { capacityQps: v })}
        />
        <Stepper
          label="Base Latency (ms)"
          value={cfg.baseLatencyMs}
          step={1}
          min={0}
          onChange={(v) => updateNodeConfig(selected.id, { baseLatencyMs: v })}
        />
        <Stepper
          label="Payload (KB)"
          value={cfg.payloadKb}
          step={1}
          min={0}
          onChange={(v) => updateNodeConfig(selected.id, { payloadKb: v })}
        />

        <label className="flex items-center justify-between gap-2">
          <span className="text-[12px] text-gray-300">Availability</span>
          <select
            value={cfg.availabilityPct}
            onChange={(e) =>
              updateNodeConfig(selected.id, { availabilityPct: Number(e.target.value) })
            }
            className="bg-panel2 border border-edge rounded-md px-2 py-1 text-sm text-gray-100"
          >
            {AVAILABILITY_TIERS.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <div className="flex justify-between text-[12px] text-gray-300">
            <span>Baseline error rate</span>
            <span className="font-mono text-gray-200">{cfg.errorRatePct}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={1}
            value={cfg.errorRatePct}
            onChange={(e) =>
              updateNodeConfig(selected.id, { errorRatePct: Number(e.target.value) })
            }
            className="mt-2 w-full"
          />
        </label>

        <div className="text-[11px] text-gray-500 bg-panel2 rounded-md px-2.5 py-2 font-mono space-y-0.5">
          <div>effective capacity: {totalCapacity.toLocaleString()} qps</div>
          {selected.data.inRateQps !== undefined && (
            <>
              <div>incoming: {Math.round(selected.data.inRateQps).toLocaleString()} qps</div>
              <div>
                success: {(selected.data.successRatePct ?? 100).toFixed(1)}% · latency:{' '}
                {Math.round(selected.data.latencyMs ?? 0)} ms
              </div>
            </>
          )}
          {selected.data.spof && (
            <div className="flex items-center gap-1 text-warn">
              <AlertTriangle size={12} /> single point of failure
            </div>
          )}
        </div>

        {activeChaos.length > 0 && (
          <div>
            <div className="text-[11px] text-gray-400 mb-1">Active chaos</div>
            <div className="flex flex-wrap gap-1.5">
              {activeChaos.map((c) => {
                const ChaosIcon = CHAOS_META[c.type].icon;
                return (
                  <span
                    key={c.type}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-md bg-bad/20 text-bad"
                  >
                    <ChaosIcon size={11} /> {CHAOS_META[c.type].label}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
