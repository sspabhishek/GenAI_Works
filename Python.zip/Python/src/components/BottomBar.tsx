import { Play, RotateCcw, Square } from 'lucide-react';
import { useStore } from '../store/useDesignStore';

function Slider({
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (v: number) => string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex flex-col gap-1 w-48">
      <div className="flex justify-between text-[11px] text-gray-400">
        <span>{label}</span>
        <span className="font-mono text-gray-200">{format(value)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}

export function BottomBar() {
  const trafficQps = useStore((s) => s.trafficQps);
  const speed = useStore((s) => s.speed);
  const running = useStore((s) => s.running);
  const setTraffic = useStore((s) => s.setTraffic);
  const setSpeed = useStore((s) => s.setSpeed);
  const start = useStore((s) => s.start);
  const stop = useStore((s) => s.stop);
  const reset = useStore((s) => s.reset);

  return (
    <footer className="h-16 shrink-0 flex items-center gap-6 px-4 border-t border-edge bg-panel">
      <button
        onClick={running ? stop : start}
        className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-sm ${
          running
            ? 'bg-bad/20 text-bad hover:bg-bad/30'
            : 'bg-accent text-white hover:bg-blue-500'
        }`}
      >
        {running ? <Square size={15} /> : <Play size={15} />}
        {running ? 'STOP' : 'START SIMULATION'}
      </button>
      <button
        onClick={reset}
        className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm text-gray-300 hover:bg-panel2"
      >
        <RotateCcw size={15} /> RESET
      </button>

      <div className="h-8 w-px bg-edge" />

      <Slider
        label="Traffic"
        value={trafficQps}
        min={0}
        max={20000}
        step={100}
        format={(v) => `${v.toLocaleString()} qps`}
        onChange={setTraffic}
      />
      <Slider
        label="Speed"
        value={speed}
        min={0.2}
        max={5}
        step={0.2}
        format={(v) => `${v.toFixed(1)}x`}
        onChange={setSpeed}
      />
    </footer>
  );
}
