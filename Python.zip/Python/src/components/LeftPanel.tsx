import { useMemo, useState } from 'react';
import { useStore } from '../store/useDesignStore';
import { DRAG_MIME } from '../canvas/Canvas';
import { PRESETS } from '../lib/presets';
import {
  CHAOS_CATEGORIES,
  CHAOS_META,
  NODE_CATEGORIES,
  NODE_META,
  type ChaosType,
  type NodeKind,
} from '../types';

type Tab = 'presets' | 'components' | 'chaos';

const ALL_KINDS = Object.keys(NODE_META) as NodeKind[];
const ALL_CHAOS = Object.keys(CHAOS_META) as ChaosType[];

export function LeftPanel() {
  const [tab, setTab] = useState<Tab>('components');
  const [query, setQuery] = useState('');
  const [tip, setTip] = useState<{ kind: NodeKind; top: number } | null>(null);

  const addNode = useStore((s) => s.addNode);
  const injectChaos = useStore((s) => s.injectChaos);
  const clearChaos = useStore((s) => s.clearChaos);
  const loadPreset = useStore((s) => s.loadPreset);
  const chaos = useStore((s) => s.chaos);
  const nodes = useStore((s) => s.nodes);
  const selectedId = useStore((s) => s.selectedNodeId);

  const selectedName = nodes.find((n) => n.id === selectedId)?.data.label;
  const q = query.trim().toLowerCase();

  const componentGroups = useMemo(
    () =>
      NODE_CATEGORIES.map((cat) => ({
        cat,
        kinds: ALL_KINDS.filter(
          (k) =>
            NODE_META[k].category === cat &&
            (q === '' || NODE_META[k].title.toLowerCase().includes(q)),
        ),
      })).filter((g) => g.kinds.length > 0),
    [q],
  );

  const chaosGroups = useMemo(
    () =>
      CHAOS_CATEGORIES.map((cat) => ({
        cat,
        items: ALL_CHAOS.filter(
          (c) =>
            CHAOS_META[c].category === cat &&
            (q === '' || CHAOS_META[c].label.toLowerCase().includes(q)),
        ),
      })).filter((g) => g.items.length > 0),
    [q],
  );

  return (
    <aside className="w-64 shrink-0 border-r border-edge bg-panel flex flex-col">
      {/* Tabs */}
      <div className="flex p-2 gap-1">
        <TabButton active={tab === 'presets'} onClick={() => setTab('presets')}>
          Presets
        </TabButton>
        <TabButton active={tab === 'components'} onClick={() => setTab('components')}>
          Components
        </TabButton>
        <TabButton active={tab === 'chaos'} onClick={() => setTab('chaos')}>
          Chaos
        </TabButton>
      </div>

      {/* Search */}
      {tab !== 'presets' && (
        <div className="px-2 pb-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={tab === 'components' ? 'Search components' : 'Search chaos'}
            className="w-full bg-panel2 border border-edge rounded-md px-2.5 py-1.5 text-sm text-gray-100 placeholder:text-gray-500"
          />
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-2 pb-3">
        {tab === 'presets' && (
          <div className="grid grid-cols-1 gap-2 pt-1">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                onClick={() => loadPreset(p.id)}
                className="text-left px-3 py-2.5 rounded-md bg-panel2 hover:bg-[#1d2536] border border-transparent hover:border-edge"
              >
                <div className="text-sm text-gray-100 font-medium">{p.name}</div>
                <div className="text-[11px] text-gray-500 mt-0.5">{p.description}</div>
              </button>
            ))}
          </div>
        )}

        {tab === 'components' &&
          componentGroups.map(({ cat, kinds }) => (
            <div key={cat} className="mb-3">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-gray-500 px-1 mb-1.5">
                {cat}
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {kinds.map((kind) => {
                  const Icon = NODE_META[kind].icon;
                  return (
                  <button
                    key={kind}
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData(DRAG_MIME, kind);
                      e.dataTransfer.effectAllowed = 'move';
                      setTip(null);
                    }}
                    onMouseEnter={(e) =>
                      setTip({
                        kind,
                        top: e.currentTarget.getBoundingClientRect().top,
                      })
                    }
                    onMouseLeave={() => setTip(null)}
                    onClick={() =>
                      addNode(kind, {
                        x: 120 + Math.random() * 200,
                        y: 100 + Math.random() * 220,
                      })
                    }
                    className="flex items-center gap-2.5 px-2.5 py-2 rounded-md bg-panel2 hover:bg-[#1d2536] text-left text-sm text-gray-200 border border-transparent hover:border-edge cursor-grab active:cursor-grabbing"
                  >
                    <Icon size={16} strokeWidth={2} style={{ color: NODE_META[kind].color }} />
                    <span className="truncate">{NODE_META[kind].title}</span>
                  </button>
                  );
                })}
              </div>
            </div>
          ))}

        {tab === 'chaos' && (
          <>
            <div className="text-[11px] text-gray-500 px-1 mb-2">
              {selectedId ? (
                <>
                  Target: <span className="text-gray-300">{selectedName}</span>
                </>
              ) : (
                'Select a node on the canvas to target.'
              )}
            </div>
            {chaosGroups.map(({ cat, items }) => (
              <div key={cat} className="mb-3">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-gray-500 px-1 mb-1.5">
                  {cat}
                </div>
                <div className="grid grid-cols-1 gap-1.5">
                  {items.map((c) => {
                    const active = chaos.some(
                      (e) => e.nodeId === selectedId && e.type === c,
                    );
                    const Icon = CHAOS_META[c].icon;
                    return (
                      <button
                        key={c}
                        disabled={!selectedId}
                        title={CHAOS_META[c].description}
                        onClick={() => injectChaos(c)}
                        className={`flex items-center gap-2.5 px-2.5 py-2 rounded-md text-left text-sm border disabled:opacity-40 disabled:cursor-not-allowed ${
                          active
                            ? 'bg-bad/20 border-bad/50 text-bad'
                            : 'bg-panel2 hover:bg-[#2a1c1c] border-transparent hover:border-edge text-gray-200'
                        }`}
                      >
                        <Icon size={16} strokeWidth={2} />
                        <span className="truncate">{CHAOS_META[c].label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
            {chaos.length > 0 && (
              <button
                onClick={clearChaos}
                className="w-full px-2 py-2 text-[11px] rounded-md bg-bad/20 hover:bg-bad/30 text-bad"
              >
                Clear {chaos.length} active chaos
              </button>
            )}
          </>
        )}
      </div>

      {/* Hover tooltip: component overview / why-use */}
      {tip && (
        <div
          className="fixed z-50 w-64 pointer-events-none rounded-lg border border-edge bg-panel2 p-3 shadow-2xl"
          style={{ left: 268, top: Math.max(8, Math.min(tip.top, window.innerHeight - 140)) }}
        >
          <div className="flex items-center gap-2 mb-1">
            {(() => {
              const Icon = NODE_META[tip.kind].icon;
              return <Icon size={15} style={{ color: NODE_META[tip.kind].color }} />;
            })()}
            <span className="text-sm font-semibold text-gray-100">
              {NODE_META[tip.kind].title}
            </span>
          </div>
          <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1.5">
            {NODE_META[tip.kind].category} · {NODE_META[tip.kind].role}
          </div>
          <p className="text-[12px] leading-snug text-gray-300">
            {NODE_META[tip.kind].description}
          </p>
        </div>
      )}
    </aside>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 px-3 py-1.5 text-sm rounded-md font-medium ${
        active ? 'bg-accent text-white' : 'text-gray-300 hover:bg-panel2'
      }`}
    >
      {children}
    </button>
  );
}
