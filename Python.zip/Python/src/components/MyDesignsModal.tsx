import { useEffect, useState } from 'react';
import { Copy, Pencil, Trash2, X } from 'lucide-react';
import { useStore } from '../store/useDesignStore';

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export function MyDesignsModal({ onClose }: { onClose: () => void }) {
  const savedDesigns = useStore((s) => s.savedDesigns);
  const currentId = useStore((s) => s.currentDesignId);
  const refreshDesigns = useStore((s) => s.refreshDesigns);
  const loadDesignById = useStore((s) => s.loadDesignById);
  const renameSavedDesign = useStore((s) => s.renameSavedDesign);
  const deleteSavedDesign = useStore((s) => s.deleteSavedDesign);
  const duplicateSavedDesign = useStore((s) => s.duplicateSavedDesign);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  useEffect(() => {
    refreshDesigns();
  }, [refreshDesigns]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60"
      onClick={onClose}
    >
      <div
        className="w-[520px] max-h-[70vh] flex flex-col bg-panel border border-edge rounded-xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-edge">
          <div className="text-sm font-semibold text-gray-100">My Designs</div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-md hover:bg-panel2 text-gray-400 flex items-center justify-center"
          >
            <X size={15} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {savedDesigns.length === 0 && (
            <div className="text-sm text-gray-500 text-center py-8">
              No saved designs yet. Use <span className="text-gray-300">Save</span> in the
              toolbar to store the current design.
            </div>
          )}
          {savedDesigns.map((d) => (
            <div
              key={d.id}
              className={`flex items-center gap-2 px-3 py-2.5 rounded-md border ${
                d.id === currentId
                  ? 'bg-accent/10 border-accent/40'
                  : 'bg-panel2 border-transparent hover:border-edge'
              }`}
            >
              <div className="flex-1 min-w-0">
                {editingId === d.id ? (
                  <input
                    autoFocus
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    onBlur={() => {
                      renameSavedDesign(d.id, editName);
                      setEditingId(null);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        renameSavedDesign(d.id, editName);
                        setEditingId(null);
                      }
                    }}
                    className="w-full bg-canvas border border-edge rounded px-2 py-1 text-sm text-gray-100"
                  />
                ) : (
                  <>
                    <div className="text-sm text-gray-100 truncate">{d.name}</div>
                    <div className="text-[11px] text-gray-500">
                      {d.design.nodes.length} nodes · updated {timeAgo(d.updatedAt)}
                    </div>
                  </>
                )}
              </div>
              <button
                onClick={() => {
                  loadDesignById(d.id);
                  onClose();
                }}
                className="px-2.5 py-1 text-xs rounded-md bg-accent text-white hover:bg-blue-500"
              >
                Open
              </button>
              <button
                title="Rename"
                onClick={() => {
                  setEditingId(d.id);
                  setEditName(d.name);
                }}
                className="w-7 h-7 rounded-md hover:bg-panel text-gray-400 flex items-center justify-center"
              >
                <Pencil size={14} />
              </button>
              <button
                title="Duplicate"
                onClick={() => duplicateSavedDesign(d.id)}
                className="w-7 h-7 rounded-md hover:bg-panel text-gray-400 flex items-center justify-center"
              >
                <Copy size={14} />
              </button>
              <button
                title="Delete"
                onClick={() => deleteSavedDesign(d.id)}
                className="w-7 h-7 rounded-md hover:bg-bad/20 text-bad flex items-center justify-center"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
