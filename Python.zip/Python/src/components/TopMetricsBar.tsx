import { Activity, CheckCircle2, Gauge, Wifi } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useStore } from '../store/useDesignStore';

function fmtCompact(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return `${Math.round(n)}`;
}

export function TopMetricsBar() {
  const totals = useStore((s) => s.totals);
  const running = useStore((s) => s.running);

  const rps = totals?.throughputQps ?? 0;
  const latency = totals?.p50LatencyMs ?? 0;
  const success = totals?.successRatePct ?? (running ? 0 : 100);
  const bw = totals?.bandwidthMBs ?? 0;

  const successColor =
    success >= 99.9 ? '#22c55e' : success >= 95 ? '#f59e0b' : '#ef4444';

  return (
    <div className="h-9 shrink-0 flex items-center gap-8 px-6 border-b border-edge bg-canvas/60 text-sm">
      <Metric icon={Activity} color="#60a5fa" value={`${fmtCompact(rps)} RPS`} />
      <Metric icon={Gauge} color="#f472b6" value={`${Math.round(latency)}ms`} />
      <Metric icon={CheckCircle2} color={successColor} value={`${success.toFixed(3)}%`} />
      <Metric icon={Wifi} color="#a5b4fc" value={`${bw.toFixed(2)} MB/s`} />
      <div className="ml-auto flex items-center gap-2 text-xs text-gray-500">
        <span
          className="w-2 h-2 rounded-full"
          style={{ background: running ? '#22c55e' : '#6b7280' }}
        />
        {running ? 'simulating' : 'idle'}
      </div>
    </div>
  );
}

function Metric({ icon: Icon, value, color }: { icon: LucideIcon; value: string; color: string }) {
  return (
    <div className="flex items-center gap-1.5 font-mono" style={{ color }}>
      <Icon size={14} />
      <span>{value}</span>
    </div>
  );
}
