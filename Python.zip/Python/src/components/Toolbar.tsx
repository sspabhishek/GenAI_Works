import { useRef, useState } from 'react';
import {
  Download,
  FilePlus2,
  FolderOpen,
  Save,
  SaveAll,
  Upload,
} from 'lucide-react';
import { useStore } from '../store/useDesignStore';
import { MyDesignsModal } from './MyDesignsModal';

export function Toolbar() {
  const currentName = useStore((s) => s.currentDesignName);
  const dirty = useStore((s) => s.dirty);
  const saveCurrent = useStore((s) => s.saveCurrent);
  const saveAs = useStore((s) => s.saveAs);
  const newDesign = useStore((s) => s.newDesign);
  const exportDesign = useStore((s) => s.exportDesign);
  const importDesign = useStore((s) => s.importDesign);
  const renameCurrent = useStore((s) => s.renameSavedDesign);
  const currentId = useStore((s) => s.currentDesignId);

  const [showDesigns, setShowDesigns] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveAs = () => {
    const name = window.prompt('Save design as:', currentName);
    if (name) saveAs(name);
  };

  const handleExport = () => {
    const blob = new Blob([exportDesign()], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentName.replace(/\s+/g, '-').toLowerCase() || 'design'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importDesign(String(reader.result));
      if (!ok) window.alert('Could not import: invalid design file.');
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const commitName = () => {
    setEditingName(false);
    if (currentId && nameDraft.trim()) renameCurrent(currentId, nameDraft);
    else if (!currentId && nameDraft.trim()) {
      useStore.setState({ currentDesignName: nameDraft.trim() });
    }
  };

  const btn =
    'flex items-center gap-1.5 px-2.5 py-1.5 text-sm rounded-md text-gray-300 hover:bg-panel2 whitespace-nowrap';

  return (
    <header className="h-12 shrink-0 flex items-center gap-1 px-4 border-b border-edge bg-panel">
      <div className="font-semibold text-gray-100 mr-3">
        sysdesign<span className="text-accent">.sim</span>
      </div>

      {/* Current design name (click to rename) */}
      <div className="flex items-center gap-1 mr-2">
        {editingName ? (
          <input
            autoFocus
            value={nameDraft}
            onChange={(e) => setNameDraft(e.target.value)}
            onBlur={commitName}
            onKeyDown={(e) => e.key === 'Enter' && commitName()}
            className="bg-panel2 border border-edge rounded px-2 py-1 text-sm text-gray-100 w-44"
          />
        ) : (
          <button
            onClick={() => {
              setNameDraft(currentName);
              setEditingName(true);
            }}
            className="text-sm text-gray-200 hover:bg-panel2 rounded px-2 py-1 max-w-[200px] truncate"
            title="Click to rename"
          >
            {currentName}
            {dirty && <span className="text-warn ml-1">•</span>}
          </button>
        )}
      </div>

      <div className="h-6 w-px bg-edge mx-1" />

      <button onClick={newDesign} className={btn}>
        <FilePlus2 size={15} /> New
      </button>
      <button onClick={saveCurrent} className={btn}>
        <Save size={15} /> Save
      </button>
      <button onClick={handleSaveAs} className={btn}>
        <SaveAll size={15} /> Save As
      </button>
      <button onClick={() => setShowDesigns(true)} className={btn}>
        <FolderOpen size={15} /> My Designs
      </button>

      <div className="h-6 w-px bg-edge mx-1" />

      <button onClick={handleExport} className={btn}>
        <Download size={15} /> Export
      </button>
      <button onClick={() => fileInputRef.current?.click()} className={btn}>
        <Upload size={15} /> Import
      </button>
      <input
        ref={fileInputRef}
        type="file"
        accept="application/json,.json"
        className="hidden"
        onChange={handleImportFile}
      />

      <div className="ml-auto text-xs text-gray-500">
        client-side discrete-event simulation
      </div>

      {showDesigns && <MyDesignsModal onClose={() => setShowDesigns(false)} />}
    </header>
  );
}
