import { Handle, Position, type NodeProps } from 'reactflow';
import { AlertTriangle, X } from 'lucide-react';
import type { SimNodeData } from '../types';
import { NODE_META } from '../types';
import { useStore } from '../store/useDesignStore';

function statusColor(data: SimNodeData): string {
  if (data.status === 'down') return '#ef4444';
  if (data.status === 'degraded') return '#f59e0b';
  const u = data.utilization ?? 0;
  if (u >= 0.95) return '#ef4444';
  if (u >= 0.7) return '#f59e0b';
  if (data.status === 'ok') return '#22c55e';
  return '#3b5170';
}

export function SimNodeView({ id, data, selected }: NodeProps<SimNodeData>) {
  const meta = NODE_META[data.kind];
  const Icon = meta.icon;
  const border = statusColor(data);
  const util = data.utilization;
  const deleteNode = useStore((s) => s.deleteNode);

  return (
    <div
      className="group relative rounded-xl px-4 py-3 min-w-[160px] shadow-lg transition-colors"
      style={{
        background: '#0e1420',
        border: `2px solid ${selected ? '#3b82f6' : border}`,
        boxShadow: selected ? '0 0 0 3px rgba(59,130,246,0.25)' : undefined,
      }}
    >
      <Handle type="target" position={Position.Left} />

      {data.spof && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2 py-0.5 rounded-md bg-warn text-black text-[9px] font-bold uppercase tracking-wider shadow whitespace-nowrap">
          <AlertTriangle size={10} strokeWidth={2.5} /> SPOF
        </div>
      )}

      <button
        title="Delete node"
        onClick={(e) => {
          e.stopPropagation();
          deleteNode(id);
        }}
        className="absolute -top-2.5 -right-2.5 w-6 h-6 rounded-full bg-bad text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center shadow"
      >
        <X size={13} strokeWidth={2.5} />
      </button>

      <div className="flex items-center gap-2 mb-1">
        <Icon size={15} style={{ color: meta.color }} strokeWidth={2} />
        <span
          className="text-[10px] font-semibold uppercase tracking-wider"
          style={{ color: meta.color }}
        >
          {meta.title}
        </span>
      </div>
      <div className="text-sm font-medium text-gray-100">{data.label}</div>

      {util !== undefined && (
        <div className="mt-2">
          <div className="h-1.5 rounded-full bg-[#1c2434] overflow-hidden">
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${Math.min(100, util * 100)}%`,
                background: border,
              }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-gray-400 mt-1 font-mono">
            <span>{Math.round((data.inRateQps ?? 0)).toLocaleString()} qps</span>
            <span>{Math.round(data.latencyMs ?? 0)} ms</span>
          </div>
          {(data.droppedQps ?? 0) > 0.5 && (
            <div className="text-[10px] text-bad font-mono mt-0.5">
              drop {Math.round(data.droppedQps ?? 0).toLocaleString()} qps
            </div>
          )}
        </div>
      )}

      {util !== undefined && (
        <div
          className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider shadow whitespace-nowrap"
          style={{ background: border, color: '#0b0f17' }}
        >
          LOAD {Math.round(util * 100)}%
        </div>
      )}
      <Handle type="source" position={Position.Right} />
    </div>
  );
}

export const nodeTypes = { sim: SimNodeView };
