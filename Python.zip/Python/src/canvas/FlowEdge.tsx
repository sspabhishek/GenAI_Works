import { memo } from 'react';
import { BaseEdge, getSmoothStepPath, type EdgeProps } from 'reactflow';
import type { SimEdgeData } from '../types';

function healthColor(health: SimEdgeData['health']): string {
  if (health === 'down') return '#ef4444';
  if (health === 'degraded') return '#f59e0b';
  return '#22c55e';
}

function FlowEdgeImpl({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  markerEnd,
}: EdgeProps<SimEdgeData>) {
  const [edgePath] = getSmoothStepPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    borderRadius: 12,
  });

  const flow = data?.flowQps ?? 0;
  const active = flow > 0.5 && data?.health !== 'down';
  const color = active ? healthColor(data?.health) : '#3b5170';

  // Number of dots and speed scale with actual flow rate (capped for sanity).
  const dotCount = active ? Math.min(6, 1 + Math.floor(Math.log10(flow + 1))) : 0;
  const duration = active ? Math.max(1.1, 3.2 - Math.log10(flow + 1)) : 0;

  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        markerEnd={markerEnd}
        style={{ stroke: color, strokeWidth: active ? 2 : 1.5, opacity: active ? 0.9 : 0.5 }}
      />
      {Array.from({ length: dotCount }).map((_, i) => (
        <circle key={i} r={3.2} fill={color}>
          <animateMotion
            dur={`${duration}s`}
            repeatCount="indefinite"
            begin={`${(duration / dotCount) * i}s`}
            path={edgePath}
          />
        </circle>
      ))}
    </>
  );
}

export const FlowEdge = memo(FlowEdgeImpl);
export const edgeTypes = { flow: FlowEdge };
