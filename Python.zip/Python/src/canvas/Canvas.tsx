import { useCallback, useEffect, useRef, useState } from 'react';
import ReactFlow, {
  Background,
  BackgroundVariant,
  useNodesInitialized,
  useReactFlow,
  type OnSelectionChangeParams,
  type ReactFlowInstance,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { useStore } from '../store/useDesignStore';
import { nodeTypes } from './nodeTypes';
import { edgeTypes } from './FlowEdge';
import { CanvasToolbar, type CanvasMode } from './CanvasToolbar';
import type { NodeKind } from '../types';

export const DRAG_MIME = 'application/sds-node';

/** Fits the view once React Flow has measured all nodes. */
function FitOnReady() {
  const initialized = useNodesInitialized();
  const { fitView } = useReactFlow();
  useEffect(() => {
    if (initialized) fitView({ padding: 0.25, duration: 200 });
  }, [initialized, fitView]);
  return null;
}

export function Canvas() {
  const nodes = useStore((s) => s.nodes);
  const edges = useStore((s) => s.edges);
  const onNodesChange = useStore((s) => s.onNodesChange);
  const onEdgesChange = useStore((s) => s.onEdgesChange);
  const onConnect = useStore((s) => s.onConnect);
  const selectNode = useStore((s) => s.selectNode);
  const addNode = useStore((s) => s.addNode);

  const [mode, setMode] = useState<CanvasMode>('select');
  const [locked, setLocked] = useState(false);
  const instanceRef = useRef<ReactFlowInstance | null>(null);

  const onSelectionChange = useCallback(
    (params: OnSelectionChangeParams) => {
      selectNode(params.nodes[0]?.id ?? null);
    },
    [selectNode],
  );

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const kind = e.dataTransfer.getData(DRAG_MIME) as NodeKind;
      if (!kind || !instanceRef.current) return;
      const position = instanceRef.current.screenToFlowPosition({
        x: e.clientX,
        y: e.clientY,
      });
      addNode(kind, position);
    },
    [addNode],
  );

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
      onSelectionChange={onSelectionChange}
      onInit={(inst) => (instanceRef.current = inst)}
      onDrop={onDrop}
      onDragOver={onDragOver}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      fitView
      fitViewOptions={{ padding: 0.25 }}
      minZoom={0.1}
      deleteKeyCode={locked ? null : ['Delete', 'Backspace']}
      nodesDraggable={!locked}
      nodesConnectable={!locked}
      elementsSelectable={!locked}
      panOnDrag={mode === 'pan'}
      selectionOnDrag={mode === 'select' && !locked}
      proOptions={{ hideAttribution: true }}
      defaultEdgeOptions={{ type: 'flow' }}
    >
      <FitOnReady />
      <CanvasToolbar mode={mode} setMode={setMode} locked={locked} setLocked={setLocked} />
      <Background variant={BackgroundVariant.Lines} gap={28} size={1} color="#161d2b" />
    </ReactFlow>
  );
}
