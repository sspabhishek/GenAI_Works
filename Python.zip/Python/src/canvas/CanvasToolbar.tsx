import { useReactFlow } from 'reactflow';
import {
  Hand,
  Lock,
  Maximize,
  MousePointer2,
  Plus,
  Minus,
  Unlock,
} from 'lucide-react';

export type CanvasMode = 'select' | 'pan';

export function CanvasToolbar({
  mode,
  setMode,
  locked,
  setLocked,
}: {
  mode: CanvasMode;
  setMode: (m: CanvasMode) => void;
  locked: boolean;
  setLocked: (v: boolean) => void;
}) {
  const { zoomIn, zoomOut, fitView } = useReactFlow();

  const Btn = ({
    active,
    onClick,
    title,
    children,
  }: {
    active?: boolean;
    onClick: () => void;
    title: string;
    children: React.ReactNode;
  }) => (
    <button
      title={title}
      onClick={onClick}
      className={`w-8 h-8 rounded-md flex items-center justify-center transition-colors ${
        active ? 'bg-accent text-white' : 'text-gray-300 hover:bg-panel2'
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1 px-1.5 py-1.5 rounded-xl border border-edge bg-panel/95 backdrop-blur shadow-xl">
      <Btn title="Select" active={mode === 'select'} onClick={() => setMode('select')}>
        <MousePointer2 size={16} />
      </Btn>
      <Btn title="Pan" active={mode === 'pan'} onClick={() => setMode('pan')}>
        <Hand size={16} />
      </Btn>
      <div className="w-px h-5 bg-edge mx-0.5" />
      <Btn title="Zoom in" onClick={() => zoomIn({ duration: 150 })}>
        <Plus size={16} />
      </Btn>
      <Btn title="Zoom out" onClick={() => zoomOut({ duration: 150 })}>
        <Minus size={16} />
      </Btn>
      <Btn title="Fit view" onClick={() => fitView({ padding: 0.25, duration: 200 })}>
        <Maximize size={16} />
      </Btn>
      <div className="w-px h-5 bg-edge mx-0.5" />
      <Btn
        title={locked ? 'Unlock canvas' : 'Lock canvas'}
        active={locked}
        onClick={() => setLocked(!locked)}
      >
        {locked ? <Lock size={16} /> : <Unlock size={16} />}
      </Btn>
    </div>
  );
}
