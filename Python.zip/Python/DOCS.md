# System Design Simulator — Documentation

An interactive, browser-based **system-design simulator** inspired by paperdraw.dev.
Compose a distributed architecture on a canvas, push traffic through it, inject failures
(chaos), and watch **live, first-principles metrics** — throughput, latency percentiles,
success rate, bandwidth, per-node load, and single-point-of-failure detection.

> **Core principle — no fake data.** Every number is computed by the simulation engine
> from your design and inputs. Nothing is mocked or hard-coded.

---

## Table of contents

1. [Quick start](#quick-start)
2. [High-level architecture](#high-level-architecture)
3. [How the engine works](#how-the-engine-works)
4. [The M/M/c queueing model & Erlang-C](#the-mmc-queueing-model--erlang-c)
5. [End-to-end metric composition](#end-to-end-metric-composition)
6. [Chaos engineering model](#chaos-engineering-model)
7. [Project structure](#project-structure)
8. [Data model](#data-model)
9. [Validation & testing](#validation--testing)
10. [Deployment guide](#deployment-guide)
11. [Cost model at scale](#cost-model-at-scale)
12. [Future enhancements](#future-enhancements)

---

## Quick start

```powershell
npm install
npm run dev      # dev server at http://localhost:5173
npm run build    # tsc -b && vite build  (must pass before shipping)
npm run preview  # preview the production build
npx tsx scripts/validate.ts   # audit components, chaos & presets
```

**Prerequisites:** Node.js 20+ and npm. No backend or accounts required — everything
runs in the browser.

---

## High-level architecture

The entire simulation runs **client-side in a Web Worker**, which is why the app stays
smooth and costs almost nothing to host.

```mermaid
flowchart TB
    subgraph Browser
        UI["React UI<br/>Toolbar · Sliders · Panels"]
        Canvas["React Flow Canvas<br/>nodes + animated edges"]
        Store["Zustand Store<br/>design + metrics + lifecycle"]
        Worker["Web Worker<br/>simEngine.simulate()"]
        UI <--> Store
        Canvas <--> Store
        Store -- "init / params / start / stop / chaos" --> Worker
        Worker -- "metrics · edge flows · totals" --> Store
    end

    subgraph Future["Backend (future phases)"]
        API["Serverless API"]
        DB[("Supabase / Postgres")]
        AIProxy["AI proxy + quotas"]
        LLM["LLM provider"]
        API <--> DB
        AIProxy --> LLM
    end

    Store -. "save / load / share" .-> API
    UI -. "analyze / prompt-to-design" .-> AIProxy
    AIProxy -. "validated JSON design" .-> Store
```

**Why a Web Worker?** The engine recomputes the whole network many times per second.
Running it off the main thread keeps the UI at 60fps and isolates the pure math from
the DOM.

---

## How the engine works

`simulate(design, trafficQps, chaos)` is a **pure function** in
[src/engine/simEngine.ts](src/engine/simEngine.ts). It is deterministic, has no DOM or
React dependencies, and returns `{ perNode, edgeFlows, totals }`.

One simulation tick runs these phases:

```mermaid
flowchart LR
    A["1. Build effective nodes<br/>μ = capacity × replicas<br/>× availability × chaos"]
    --> B["2. Build DAG<br/>find sources<br/>(no inbound edges)"]
    --> C["3. Propagate arrival<br/>rates λ (relaxation)"]
    --> D["4. Per-node M/M/c<br/>Erlang-C latency,<br/>drops, errors"]
    --> E["5. Compose end-to-end<br/>latency percentiles<br/>over critical path"]
    --> F["6. SPOF detection +<br/>edge flows + totals"]
```

### 1. Effective capacity (μ)

For each node:

$$\mu = \text{capacityQps} \times \text{replicas} \times \text{availability} \times \text{chaosMultiplier}$$

### 2–3. Arrival-rate propagation (λ)

Traffic enters at **source nodes** (no inbound edges) and flows downstream. Because a
graph can have fan-out and re-convergence, rates are solved by **relaxation** (iterating
to convergence). Routing depends on the node's `role`:

- **`balancer`** (load balancer, reverse proxy, mesh) — *splits* its served traffic
  equally across successors. A request takes **one** branch.
- **everything else** — *fans out*: a request that hits an App Server also calls its
  Cache **and** Database, so each successor receives the full served rate.

### 4. Per-node service

$$\rho = \frac{\lambda}{\mu}, \qquad \text{served} = \min(\lambda(1-\text{loss}),\ \mu)\times(1-\text{error})$$

$$\text{dropped} = \max(0,\ \lambda - \text{served})$$

Latency comes from the M/M/c model below.

---

## The M/M/c queueing model & Erlang-C

Each node is modelled as an **M/M/c queue** — the standard model for a service with
`c` parallel servers (here, `c = replicas`):

- **M** — *Markovian* (Poisson) arrivals at rate λ.
- **M** — *Markovian* (exponential) service times.
- **c** — number of identical servers (replicas).

### Why M/M/c and not M/M/1?

A naïve `latency = base / (1 − ρ)` (M/M/1) assumes a **single** server and badly
over-estimates delay when you add replicas. M/M/c correctly captures that **more
replicas absorb bursts and slash queueing delay**. Example at ρ = 0.67:

| Model | App Server (3 replicas) latency |
|---|---|
| M/M/1 (old, wrong) | ~60 ms |
| **M/M/c Erlang-C (now)** | **~21 ms** |

### The math

Let `a = λ / μ_server = c·ρ` be the **offered load** in Erlangs.

**Erlang-B** (blocking probability) via a numerically stable recurrence:

$$B(0,a) = 1, \qquad B(k,a) = \frac{a\,B(k-1,a)}{k + a\,B(k-1,a)}$$

**Erlang-C** (probability an arrival must *wait*) derived from Erlang-B:

$$C(c,a) = \frac{B(c,a)}{1 - \rho\,\bigl(1 - B(c,a)\bigr)}$$

**Response time** = deterministic service time `S` + queue wait `W_q`:

$$E[R] = S + \frac{C(c,a)}{\mu - \lambda}, \qquad \operatorname{Var}[R] = \frac{C(c,a)\,\bigl(2 - C(c,a)\bigr)}{(\mu - \lambda)^2}$$

These are implemented exactly in `erlangB()`, `erlangC()`, and `queueStats()`.

```mermaid
flowchart TB
    L["λ arrivals/sec (Poisson)"] --> Q{"Queue"}
    Q -->|"P(wait) = C(c,a)"| W["wait ~ Exp(μ−λ)"]
    Q -->|"1 − C(c,a)"| NW["no wait"]
    W --> S
    NW --> S["c servers<br/>(replicas)<br/>service time S"]
    S --> R["Response R = S + W_q<br/>mean & variance returned"]
```

When ρ ≥ 1 the node is **saturated** (unbounded queue); the engine reports a large
finite penalty and flags the node `degraded`/over-100%-LOAD instead of returning ∞.

---

## End-to-end metric composition

### Latency percentiles

Per-node mean and variance are summed along the **critical path** (the slowest path by
mean). Percentiles are then composed with a normal (Central Limit Theorem) approximation:

$$\mu_{\text{path}} = \sum_i E[R_i], \quad \sigma_{\text{path}} = \sqrt{\textstyle\sum_i \operatorname{Var}[R_i]}$$

$$p_{50} = \mu_{\text{path}}, \qquad p_{99} = \mu_{\text{path}} + 2.326\,\sigma_{\text{path}}$$

This replaced the earlier fabricated `p99 = p50 × 2.5`.

### Success rate (path-aware)

A request succeeds only if **every** node on its route serves it. Success is computed
recursively over the DAG:

$$\text{success}(n) = \text{localRatio}(n) \times \text{downstream}(n)$$

where `localRatio = served / incoming`, and `downstream` is:

- the **average** of successor successes for a **`balancer`** (request takes one branch);
- the **product** of successor successes otherwise (fan-out — all calls must succeed).

`completionFraction` is the traffic-weighted average over sources;
`throughput = traffic × completionFraction` and `successRate = completionFraction × 100`.

### Bandwidth & SPOF

- **Bandwidth** = Σ(served × payloadKb) / 1024 MB/s across all nodes.
- **SPOF** — a load-bearing single-replica node whose removal disconnects otherwise
  reachable nodes from all sources is flagged (graph reachability diff).

---

## Chaos engineering model

Chaos events mutate a node's effective parameters **at runtime**, so metrics react live.
Each `ChaosType` maps to a `chaosEffect()` returning multipliers:

| Field | Meaning |
|---|---|
| `muMul` | capacity multiplier (0 = down) |
| `latMul` | base-latency multiplier |
| `lossFactor` | fraction of inbound requests dropped pre-service |
| `addError` | added post-service error fraction |
| `forcedDown` | node fully offline |

There are **6 categories**: Infrastructure, Network, Application-Level, Data Layer,
Traffic, and Dependency chaos. The validation script asserts **every** chaos type has a
measurable effect (no decorative entries).

---

## Project structure

```
src/
  canvas/      Canvas.tsx (React Flow + grid + drag/drop),
               nodeTypes.tsx (node card, LOAD%/SPOF badges, delete),
               FlowEdge.tsx (animated traffic dots),
               CanvasToolbar.tsx (select/pan/zoom/fit/lock)
  engine/      simEngine.ts — pure M/M/c queueing-network solver
  workers/     sim.worker.ts — runs the engine on a timer
  store/       useDesignStore.ts — Zustand state + worker messaging + persistence
  components/  Toolbar, TopMetricsBar, LeftPanel (Presets/Components/Chaos tabs),
               Inspector (Component Settings), MetricsPanel, BottomBar, MyDesignsModal
  lib/         defaultDesign.ts, presets.ts, storage.ts
  types/       index.ts — shared types + NODE_META + CHAOS_META + metadata
scripts/
  validate.ts  standalone accuracy audit (run with: npx tsx scripts/validate.ts)
```

---

## Data model

Key shared types live in [src/types/index.ts](src/types/index.ts):

- **`NodeKind`** — 48 component kinds grouped by `NodeCategory` (Network & Edge, Compute,
  Data & Storage, Messaging, AI & Agents, Security, Observability, Data Engineering),
  each with a routing `NodeRole` (`entry` / `balancer` / `service` / `store`).
- **`NodeConfig`** — `capacityQps`, `baseLatencyMs`, `replicas`, `errorRatePct`,
  `payloadKb`, `availabilityPct`.
- **`ChaosType`** — 42 failure modes across 6 `ChaosCategory` groups.
- **`SimResult`** — `{ perNode, edgeFlows, totals }`, shared identically across
  engine ↔ worker ↔ store.

Persistence (local, multi-design) is in [src/lib/storage.ts](src/lib/storage.ts) under
the `localStorage` key `sds.designs.v1`.

---

## Validation & testing

[scripts/validate.ts](scripts/validate.ts) runs the **real engine** against the whole
catalog and fails (non-zero exit) on any issue:

- **Components** — valid role/category/description and sane, finite defaults.
- **Chaos** — every type must produce a *measurable* change vs. baseline.
- **Presets** — all edges reference real nodes, ≥1 source exists, and totals are finite
  and in range.

```powershell
npx tsx scripts/validate.ts
```

Always run `npm run build` (TypeScript + Vite) and the validation script before shipping.

---

## Deployment guide

Because the simulation is client-side, deployment is just **static hosting**.

### Option A — Vercel (recommended)

1. Push the repo to GitHub.
2. Import it in Vercel. Framework preset: **Vite**.
3. Build command `npm run build`, output directory `dist`.
4. Deploy — done. Every push gets a preview URL.

### Option B — Cloudflare Pages / Netlify / GitHub Pages

- Build command: `npm run build`; publish directory: `dist`.
- For GitHub Pages set Vite `base` to your repo path in `vite.config.ts`.

### Option C — any static host / container

```powershell
npm run build           # produces dist/
npx serve dist          # or copy dist/ to nginx, S3+CloudFront, etc.
```

```mermaid
flowchart LR
    Dev["git push"] --> CI["Vercel / CF Pages build<br/>npm run build"]
    CI --> CDN["Static assets on CDN<br/>(dist/)"]
    CDN --> User["User browser<br/>runs sim in Web Worker"]
```

**Notes**
- No server, database, or secrets are required for the current app.
- Web Workers need correct MIME types — all the above hosts handle Vite output natively.
- Set a cache policy: long cache for hashed `assets/*`, no-cache for `index.html`.

---

## Cost model at scale

Client-side execution keeps costs near zero. Indicative monthly cost at **100k MAU**:

| Workload | Approach | Est. cost |
|---|---|---|
| Frontend + simulation | Static CDN + Web Worker | $0–20 |
| Save / load / accounts | Serverless + managed Postgres (Supabase) | $25–50 |
| Bandwidth | CDN egress | $10–30 |
| **Subtotal (no AI)** | | **~$50–100** |
| AI features | LLM usage, gated behind Pro + quotas | the only real variable |

The wildcard is AI: gate it behind auth + per-user quotas + a cheap default model so
usage cost is covered by the users generating it.

---

## Future enhancements

### Engine / accuracy
- **Discrete-event simulation mode** — individual requests with Poisson arrivals, retry
  storms, and *measured* percentile latencies (vs. the analytic CLT composition).
- **Retry & timeout modelling** — capture retry amplification and timeout cutoffs.
- **Autoscaling** — nodes that add replicas as utilization rises.
- **Cost overlay** — $/month per node from instance sizing.

### Product
- **Persistence & accounts (Supabase)** — cloud-saved designs, shareable links, public
  library. The local design-manager UI is already built to slot in.
- **Freemium + design challenges** — gate advanced chaos/components behind Pro; gamified
  "handle X QPS under $Y" challenges.
- **AI layer (Pro)**:
  - *Analyze* — send a compact metrics summary, get bottleneck + concrete fixes.
  - *Prompt-to-design* — LLM returns validated `{nodes, edges}` JSON, rendered and
    auto-simulated. Must go through a backend proxy with auth, quotas, and schema
    validation (guard against prompt injection / malformed graphs).

### UX
- Multi-select, copy/paste, undo/redo.
- Edge labels showing live qps; minimap.
- Export to PNG/SVG; import from other diagram tools.
- Keyboard shortcuts and a command palette.

```mermaid
flowchart LR
    Now["Now:<br/>analytic M/M/c<br/>local persistence"]
    --> P5["Phase 5:<br/>Supabase accounts<br/>+ sharing"]
    --> P6["Phase 6:<br/>freemium +<br/>challenges"]
    --> P7["Phase 7:<br/>AI analyze +<br/>prompt-to-design"]
    --> P8["Phase 8:<br/>discrete-event<br/>engine mode"]
```

---

See also: [CLAUDE.md](CLAUDE.md) · [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) ·
[TASKS.md](TASKS.md) · [README.md](README.md)
