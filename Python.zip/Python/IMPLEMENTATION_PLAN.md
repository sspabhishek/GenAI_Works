# Implementation Plan — System Design Simulator

A web platform (inspired by **paperdraw.dev**) where users visually build system
architectures, run a **discrete-event simulation** with adjustable traffic, inject
**chaos** (failures), and watch live metrics — plus an **AI layer** for analysis and
prompt-to-design.

---

## 1. Product Overview

| Aspect | Description |
|---|---|
| Core idea | Drag-and-drop system components, connect them, simulate traffic & failures |
| Components | API Gateway, Load Balancer (L4/L7), App Server, Cache (Redis), Database (Postgres) |
| Simulation | Discrete-event engine: requests flow through nodes with capacity, latency, queues |
| Controls | **Traffic** slider (QPS), **Speed** slider (sim time scale), START/RESET |
| Chaos | Instance crash, VM CPU spike, disk failure, packet loss, high latency, network partition |
| Metrics | p50 / p99 latency, throughput, dropped requests, per-node utilization |
| AI (Pro) | (A) Analyze simulation → suggest fixes, (B) Prompt → generate a design |
| Business | Freemium (free tier + Pro upsell), publish/challenge gamification |

---

## 2. Architecture Principles

1. **Simulation runs client-side in a Web Worker** — keeps the UI smooth and servers
   cheap even at 100k MAU.
2. **Decouple math from rendering** — the engine emits events; the UI animates them.
3. **Chaos is first-class** — runtime events mutate node state mid-simulation.
4. **AI is gated** behind auth + per-user quotas + a cheap default model (Pro upsell).

---

## 3. Tech Stack

| Layer | Choice |
|---|---|
| Build / framework | Vite + React + TypeScript |
| Canvas / editor | React Flow |
| State management | Zustand |
| Styling / UI | Tailwind CSS |
| Charts | Recharts |
| Simulation | TypeScript in a Web Worker |
| Backend (later) | Supabase (auth + Postgres) |
| AI (later) | Serverless proxy → LLM (cheap model default) |
| Deploy | Vercel / Cloudflare Pages (frontend) + Supabase |

---

## 4. System Architecture Flow

```mermaid
flowchart TB
    subgraph Browser
        UI[React UI<br/>Toolbar + Sliders + Panels]
        Canvas[React Flow Canvas<br/>nodes + edges]
        Store[Zustand Store<br/>design + metrics]
        Worker[Web Worker<br/>Discrete-Event Sim Engine]
        UI <--> Store
        Canvas <--> Store
        Store -->|design + start/stop| Worker
        Worker -->|metrics + traffic events| Store
    end
    subgraph Backend [Backend - later phases]
        API[Serverless API]
        DB[(Supabase / Postgres)]
        AIProxy[AI Proxy + quotas]
        LLM[LLM provider]
        API <--> DB
        AIProxy --> LLM
    end
    Store -->|save/load/share| API
    UI -->|analyze / prompt-to-design| AIProxy
    AIProxy -->|validated JSON design| Store
```

---

## 5. Simulation Working Flow

```mermaid
sequenceDiagram
    participant U as User
    participant S as Store (main thread)
    participant W as Sim Worker
    participant C as Canvas / Charts

    U->>S: Set Traffic (QPS) + Speed, click START
    S->>W: postMessage(start, {design, qps, speed})
    loop every sim tick
        W->>W: generate arrivals (Poisson)
        W->>W: route request along edges
        W->>W: enqueue at node, apply service time + capacity
        W->>W: drop if queue full; record latency
        W-->>S: postMessage(metrics + traffic events)
        S->>C: update node health colors + animate packets + charts
    end
    U->>S: Inject chaos (e.g. crash App Server)
    S->>W: postMessage(chaos, {nodeId, type})
    W->>W: mutate node state (down / +latency / drop %)
    Note over W,C: Metrics react live — bottleneck turns red
    U->>S: STOP / RESET
    S->>W: postMessage(stop)
```

---

## 6. Phased Delivery

### Phase 0 — Scaffold & Foundation
- Vite + React + TS, Tailwind, ESLint.
- Install React Flow, Zustand, Recharts.
- Folder structure (`canvas/`, `engine/`, `workers/`, `store/`, `components/`, `types/`).
- **Deliverable:** empty themed canvas runs via `npm run dev`.

### Phase 1 — Canvas & Typed Nodes
- Custom node types with config (capacity QPS, base latency, replicas).
- Palette to add nodes, connect edges, edit labels.
- Save / load design as JSON (localStorage).
- **Deliverable:** editable, persistent architecture canvas.

### Phase 2 — Discrete-Event Simulation Engine ⭐
- DES engine in a Web Worker: event queue on a virtual timeline.
- Poisson arrivals driven by Traffic slider; nodes as M/M/c queues.
- Metrics: p50/p99 latency, throughput, drops, utilization.
- Speed slider controls sim-time scale.
- **Deliverable:** START → live metrics.

### Phase 3 — Live Visualization
- Animate request packets along edges.
- Color nodes by health (green → amber → red).
- Live metrics panel + Recharts time-series.
- **Deliverable:** visible traffic + bottleneck highlighting.

### Phase 4 — Chaos Engineering
- Runtime fault events that mutate node state mid-run.
- Chaos panel: infrastructure + network failures.
- **Deliverable:** crash a node mid-sim → metrics react live.

### Phase 5 — Persistence & Accounts (backend)
- Supabase auth, save designs, My Designs, shareable links, public Library.

### Phase 6 — Freemium & Challenges
- Free vs Pro feature gating; publish-challenge gamification.

### Phase 7 — AI Layer (Pro)
- Backend proxy with auth + quotas + cheap default model.
- (A) Analyze sim metrics → suggestions.
- (B) Prompt → validated JSON design → render → auto-simulate.

---

## 7. Milestones

| Milestone | Phases | Outcome |
|---|---|---|
| **M1** | 0–1 | Editable, persistent canvas |
| **M2** | 2–3 | Working simulation + live metrics ← *core value* |
| **M3** | 4 | Chaos engineering |
| **M4** | 5–6 | Accounts, library, freemium |
| **M5** | 7 | AI features |

---

## 8. Cost & Deployment Summary

- **Frontend + sim:** static hosting + client-side Web Worker → near-zero server cost.
- **Non-AI cost @ 100k MAU:** ~$50–100/month (hosting + managed Postgres + bandwidth).
- **AI cost:** the variable — gate behind Pro, quotas, and a cheap default model.
- **Deploy:** Vercel / Cloudflare Pages (frontend) + Supabase (auth/db) + serverless AI proxy.
