# Tasks — System Design Simulator

Status legend: `[ ]` todo · `[~]` in progress · `[x]` done

---

## Phase 0 — Scaffold & Foundation
- [x] T0.1 Scaffold Vite + React + TypeScript project
- [x] T0.2 Install dependencies: React Flow, Zustand, Recharts
- [x] T0.3 Install & configure Tailwind CSS
- [x] T0.4 Create folder structure (`canvas/`, `engine/`, `workers/`, `store/`, `components/`, `types/`, `lib/`)
- [x] T0.5 Apply dark theme base layout (toolbar + canvas + side panels)
- [x] T0.6 Verify `npm run dev` renders empty themed canvas

## Phase 1 — Canvas & Typed Nodes
- [x] T1.1 Define shared types (`NodeType`, `SimNode`, `SimEdge`, `Metrics`)
- [x] T1.2 Build custom node components (API Gateway, Load Balancer, App Server, Cache, Database)
- [x] T1.3 Node config (capacity QPS, base latency, replicas)
- [x] T1.4 Component palette / sidebar to add nodes
- [x] T1.5 Edge connection + labels
- [x] T1.6 Zustand store for design state
- [x] T1.7 Save / load design as JSON (localStorage)

## Phase 2 — Discrete-Event Simulation Engine
- [x] T2.1 Define worker message protocol (start/stop/chaos/metrics/tick)
- [x] T2.2 Implement event queue + virtual clock
- [x] T2.3 Poisson arrival generator driven by Traffic (QPS)
- [x] T2.4 Node service model (M/M/c queue: capacity, service time, queue limit)
- [x] T2.5 Request routing along edges
- [x] T2.6 Metrics collection (p50/p99 latency, throughput, drops, utilization)
- [x] T2.7 Speed slider → sim-time scaling
- [x] T2.8 Wire worker ↔ store ↔ START/RESET buttons

## Phase 3 — Live Visualization
- [x] T3.1 Node health coloring by utilization (green → amber → red)
- [x] T3.2 Animate request packets along edges (FlowEdge dots, density/speed by flow)
- [x] T3.3 Live metrics panel
- [x] T3.4 Recharts time-series (latency + throughput)
- [x] T3.5 Square grid background (paperdraw style)
- [x] T3.6 Top metrics bar (RPS / latency / success% / bandwidth)
- [x] T3.7 LOAD% and SPOF badges on nodes
- [x] T3.8 Drag-and-drop components onto the canvas
- [x] T3.9 Component Settings panel (steppers, availability dropdown, delete/close)
- [x] T3.10 Accurate end-to-end success rate + bandwidth (no fake data)
- [x] T3.11 Preset library (Basic Web, Edge+CDN, Microservices, Event-Driven, Search)
- [x] T3.12 Expanded chaos (16 types) with real effects + descriptions

## Phase 4 — Chaos Engineering
- [x] T4.1 Chaos event types (crash, CPU spike, disk failure, packet loss, high latency, partition)
- [x] T4.2 Chaos panel UI (infrastructure + network groups)
- [x] T4.3 Apply chaos at runtime (mutate node state mid-sim)
- [x] T4.4 Verify metrics react live to injected faults

## Phase 5 — Persistence & Accounts (backend, later)
- [x] T5.0 Local multi-design persistence (localStorage): save/save-as/load/rename/duplicate/delete
- [x] T5.0b My Designs modal + current-design name & dirty indicator
- [x] T5.0c Export / Import design as JSON file
- [ ] T5.1 Supabase project + auth
- [ ] T5.2 Save designs to Postgres
- [ ] T5.3 My Designs + shareable links
- [ ] T5.4 Public Library

## Phase 6 — Freemium & Challenges (later)
- [ ] T6.1 Free vs Pro feature gating
- [ ] T6.2 Lock advanced chaos behind Pro
- [ ] T6.3 Publish-design challenge flow

## Phase 7 — AI Layer (Pro, later)
- [ ] T7.1 Serverless AI proxy (auth + quotas + cheap default model)
- [ ] T7.2 Feature A: analyze sim metrics → suggestions
- [ ] T7.3 Feature B: prompt → validated JSON design → render → auto-simulate
- [ ] T7.4 Output validation + prompt-injection safeguards

## Cross-Cutting
- [x] X.1 Verify production build (`npm run build`)
- [x] X.2 Basic README with run instructions
- [x] X.4 CLAUDE.md project guide for AI agents
- [ ] X.3 Deploy config (Vercel/Cloudflare) — later
