# Build Prompt — System Design Simulator (from scratch)

> Paste everything below the line into an AI coding agent on the new device. It is a
> complete, self-contained specification to build the app from zero through Phase 7.
> Build it phase by phase; after each phase run `npm run build` and fix all errors
> before continuing.

---

## ROLE & GOAL

You are building an interactive, browser-based **system design simulator** inspired by
paperdraw.dev. Users visually compose a distributed-system architecture on a canvas, run a
**queueing-network simulation** driven by adjustable traffic, inject **chaos** (failures),
and watch **live, computed metrics** — throughput, latency percentiles, success rate,
bandwidth, per-node load, and single-point-of-failure (SPOF) detection.

**Hard rules (never break these):**
1. **NO fake/mocked/hard-coded metrics.** Every number shown must be computed by the
   simulation engine from the user's design and inputs.
2. **Simulation runs client-side in a Web Worker.** The engine is a pure function with no
   DOM/React imports.
3. **No emojis in the UI.** Use a professional icon library (`lucide-react`) everywhere.
4. After each phase: `npm run build` must pass (run `tsc -b && vite build`), and a
   validation script must pass.
5. Keep the engine explainable and deterministic.

---

## TECH STACK

- **Vite + React + TypeScript**
- **React Flow** (`reactflow`) — node/edge canvas
- **Zustand** — state management
- **Tailwind CSS v3** + PostCSS + Autoprefixer
- **Recharts** — live metric charts
- **lucide-react** — icons (no emojis)
- **Web Worker** — runs the engine on a timer
- Phase 5+: **Supabase** (auth + Postgres). Phase 7: serverless **AI proxy** + an LLM.

Scaffold:
```bash
npm create vite@latest . -- --template react-ts
npm install reactflow zustand recharts lucide-react
npm install -D tailwindcss@3 postcss autoprefixer
```

Project structure:
```
src/
  canvas/      Canvas.tsx, nodeTypes.tsx, FlowEdge.tsx, CanvasToolbar.tsx
  engine/      simEngine.ts          (pure M/M/c queueing solver)
  workers/     sim.worker.ts         (runs engine on a timer)
  store/       useDesignStore.ts     (Zustand + worker messaging + persistence)
  components/  Toolbar, TopMetricsBar, LeftPanel, Inspector, MetricsPanel,
               BottomBar, MyDesignsModal
  lib/         defaultDesign.ts, presets.ts, storage.ts
  types/       index.ts              (all shared types + NODE_META + CHAOS_META)
scripts/
  validate.ts  (standalone accuracy audit, run with: npx tsx scripts/validate.ts)
```

---

## DATA MODEL (`src/types/index.ts`)

- `NodeKind` — a large union of component kinds, grouped by `NodeCategory`:
  `'Network & Edge' | 'Compute' | 'Data & Storage' | 'Messaging' | 'AI & Agents' |
  'Security' | 'Observability' | 'Data Engineering'`. Aim for ~45+ kinds (API Gateway,
  Load Balancer, Reverse Proxy, CDN, DNS, Rate Limiter, Firewall/WAF, Service Mesh, NAT
  Gateway, VPN Gateway, App Server, Serverless Fn, Worker, Auth Service, Scheduler, Media
  Processor, Notification Service, Search Service, Database, Cache, Object Storage, Search
  Index, KV Store, Graph DB, Time Series DB, Data Warehouse, Data Lake, Vector DB, Message
  Queue, Event Stream, Pub/Sub, LLM Gateway, Agent Orchestrator, Tool Registry, DDoS
  Shield, SIEM, Secrets Manager, HSM, Fraud Detection, Log Aggregator, Metrics Collector,
  Distributed Tracing, Alerting, ETL Pipeline, CDC Service, Batch Processor, Feature Store,
  Schema Registry).
- `NodeRole = 'entry' | 'balancer' | 'service' | 'store'` — controls routing.
- `NodeConfig = { capacityQps, baseLatencyMs, replicas, errorRatePct, payloadKb, availabilityPct }`.
- `NODE_META: Record<NodeKind, { title, category, role, icon: LucideIcon, color, description, defaults: NodeConfig }>`.
  The `description` is a 1–2 sentence "what it is / why you'd use it" overview shown on hover.
- `ChaosType` — ~40 failure modes grouped by `ChaosCategory`:
  `'Infrastructure Failures' | 'Network Chaos' | 'Application-Level Chaos' |
  'Data Layer Chaos' | 'Traffic Chaos' | 'Dependency Chaos'`.
- `CHAOS_META: Record<ChaosType, { label, category, icon: LucideIcon, description }>`.
- Sim I/O types: `SimNodeData`, `SimEdgeData` (`flowQps`, `health`), `NodeMetric`,
  `EdgeFlow`, `SimTotals` (`throughputQps, droppedQps, p50LatencyMs, p99LatencyMs,
  offeredQps, successRatePct, bandwidthMBs`), `SeriesPoint`, `SimResult =
  { perNode, edgeFlows, totals }`, and worker messages `ToWorker` / `FromWorker`.
- `AVAILABILITY_TIERS` (90 / 99 / 99.9 / 99.99 / 99.999%).

---

## THE SIMULATION ENGINE (`src/engine/simEngine.ts`) — CRITICAL, MUST BE ACCURATE

Export a **pure** function:
`simulate(design, trafficQps, chaos: ChaosEvent[]): SimResult`.

Per tick:

1. **Effective capacity** per node:
   `μ = capacityQps × replicas × availability × chaosMuMultiplier`.
2. **Build the DAG**; sources = nodes with no inbound edges. Split incoming `trafficQps`
   equally across sources.
3. **Propagate arrival rates λ by relaxation** (iterate ~nodeCount+1 times). Routing:
   - `role === 'balancer'` → split served traffic **equally** among successors (request
     takes ONE branch).
   - otherwise → **fan out** the full served rate to every successor (a request hits
     App Server AND its Cache AND its Database).
4. **Per node:** `ρ = λ/μ`, `served = min(λ·(1−loss), μ)·(1−error)`, `dropped = max(0, λ−served)`.
5. **Latency = exact M/M/c queue (Erlang-C)** — NOT M/M/1. Implement:
   - Erlang-B recurrence: `B(0)=1; B(k) = a·B(k−1) / (k + a·B(k−1))` where `a = c·ρ`, `c = replicas`.
   - Erlang-C: `C = B / (1 − ρ·(1 − B))`.
   - Response time mean `= serviceMs + (C/(μ−λ))·1000`; variance `= C·(2−C)/(μ−λ)²·1e6`.
   - If `ρ ≥ 1` → saturated: return a large finite penalty (`serviceMs×50`) and mark degraded.
6. **End-to-end percentiles:** sum per-node mean & variance along the **critical (max-mean)
   path**; compose `p50 = μ_path`, `p99 = μ_path + 2.326·σ_path` (normal/CLT). Never a fixed
   multiplier.
7. **Success rate (path-aware), recursive over the DAG:**
   `success(n) = localRatio(n) × downstream(n)`, where `localRatio = served/incoming`, and
   `downstream` = **average** of successors for a `balancer` (one branch taken), **product**
   otherwise (fan-out: all calls must succeed). `completionFraction` = avg over sources;
   `throughput = traffic × completionFraction`; `successRate = completionFraction × 100`.
8. **Bandwidth** = Σ(served × payloadKb)/1024 MB/s. **SPOF** = a single-replica load-bearing
   node whose removal disconnects otherwise-reachable nodes from all sources (reachability diff).
9. **Chaos** maps each `ChaosType` to `{ muMul, latMul, lossFactor, addError, forcedDown }`
   and mutates the node's effective params. Every chaos type must have a measurable effect.

`src/workers/sim.worker.ts`: hold design/traffic/speed/chaos; on `start` run `simulate` on
`setInterval` (interval scaled by speed); post `{ metrics, result, point }` back. Handle
`init / params / start / stop / chaos / clearChaos`.

---

## STATE (`src/store/useDesignStore.ts`)

Zustand store owning: `nodes, edges, trafficQps, speed, running, selectedNodeId, chaos,
totals, series`, plus persistence fields `currentDesignId, currentDesignName, dirty,
savedDesigns`. Create the Worker via
`new Worker(new URL('../workers/sim.worker.ts', import.meta.url), { type: 'module' })`.
Actions: node/edge CRUD (set `dirty`), `addNode`, `deleteNode` (also removes its edges +
chaos), `updateNodeConfig`, `renameNode`, `setTraffic`, `setSpeed`, `start`, `stop`, `reset`,
`injectChaos`, `clearChaos`, `applyMetrics`, persistence actions (below), `loadPreset(id)`.

**Critical bug to avoid:** on `stop()`, zero every `edge.data.flowQps` so animated dots
stop, and make `applyMetrics` early-return if `!running` (ignore late worker messages).

---

## UI

- **Dark, square-grid canvas** (React Flow `Background variant=Lines`, gap ~28).
- **Custom node card** (`nodeTypes.tsx`): lucide icon + title + label, a utilization bar,
  live `qps`/`ms`, a **LOAD %** badge, a **SPOF** badge, and a delete (✕ icon) button on hover.
  Color by health (green→amber→red).
- **Animated edges** (`FlowEdge.tsx`): dots traveling along the path via SVG `animateMotion`;
  dot count/speed scale with actual `flowQps`; color by source health. Edge type `'flow'`.
- **Canvas toolbar** (`CanvasToolbar.tsx`, floating top-center): Select, Pan, Zoom in/out,
  Fit view, Lock (lock disables drag/select/delete). Use `useReactFlow()`.
- **LeftPanel**: tabbed **Presets / Components / Chaos**, with search. Components are
  **draggable** onto the canvas (drag-and-drop via a custom MIME + `screenToFlowPosition`)
  and grouped by category. **Hovering a component shows a tooltip** with its
  title, category·role, and description. Chaos items are grouped by category and target the
  selected node.
- **Inspector** ("Component Settings"): icon + editable name, +/- **steppers** for Replicas,
  Capacity (RPS), Base Latency, Payload (KB); an **Availability dropdown**; an error-rate
  slider; live readouts; delete + close buttons in the header.
- **TopMetricsBar**: RPS, latency, success %, bandwidth (all from `totals`), plus a
  running/idle indicator.
- **BottomBar**: START/STOP + RESET (with Play/Square/Rotate icons) and **Traffic** + **Speed**
  sliders.
- **MetricsPanel**: stat tiles + a Recharts time-series of throughput/dropped/success.
- Fit the view once nodes are measured (use React Flow's `useNodesInitialized`).

---

## PRESETS (`src/lib/presets.ts`)

Provide a `PRESETS` array of `{ id, name, description, build(): Design }`. Include simple
ones (Basic Web App, Edge+CDN, Microservices, Event-Driven, Search Stack) **and complex
FAANG-interview designs**: URL Shortener (TinyURL), Video Streaming (Netflix/YouTube),
Social Feed (Twitter/Instagram), Ride Sharing (Uber/Lyft), Chat (WhatsApp), E-Commerce
Checkout (Amazon), AI RAG Platform (LLM). Every edge must reference real node ids and use
type `'flow'`; every design must have ≥1 source node.

---

## VALIDATION (`scripts/validate.ts`, run with `npx tsx scripts/validate.ts`)

A standalone script (no DOM) that imports the real engine and asserts (exit non-zero on fail):
- Every component: valid role/category, non-empty description, finite/positive defaults.
- Every chaos type: produces a **measurable** change vs. baseline on a probe design.
- Every preset: edges reference existing nodes, ≥1 source exists, and engine totals are
  finite and in range (success 0–100, throughput ≥ 0, etc.).
Keep this green at every phase.

---

## PHASES 0–4 (the client-side app — build these first)

- **Phase 0** — Scaffold (Vite+React+TS, Tailwind, folders).
- **Phase 1** — Canvas + typed nodes + edges + drag/drop + local default design.
- **Phase 2** — Engine in a Web Worker; Traffic/Speed sliders; START/RESET; live per-node
  + total metrics (the M/M/c math above).
- **Phase 3** — Live visualization: animated flow dots, node health colors, LOAD%/SPOF
  badges, top metrics bar, Recharts panel, canvas toolbar.
- **Phase 4** — Chaos: full `CHAOS_META` catalog + runtime injection that mutates nodes live.
- Plus: local multi-design persistence (`src/lib/storage.ts` over `localStorage` key
  `sds.designs.v1`): Save / Save As / load / rename / duplicate / delete, a **My Designs**
  modal, and Export/Import design as JSON.

---

## PHASE 5 — ACCOUNTS & CLOUD PERSISTENCE (Supabase)

Goal: real auth + cloud-saved designs + shareable links, reusing the existing design-manager UI.

1. **Setup**: create a Supabase project. Add `@supabase/supabase-js`. Put `VITE_SUPABASE_URL`
   and `VITE_SUPABASE_ANON_KEY` in `.env.local` (never commit secrets). Create
   `src/lib/supabase.ts` exporting a configured client.
2. **Auth**: email magic-link / OAuth via Supabase Auth. Add an `AuthModal` and show the
   signed-in user in the Toolbar; gate cloud actions behind sign-in.
3. **Schema** (SQL in Supabase):
   ```sql
   create table designs (
     id uuid primary key default gen_random_uuid(),
     owner uuid references auth.users(id) on delete cascade,
     name text not null,
     graph jsonb not null,         -- { nodes, edges }
     is_public boolean default false,
     created_at timestamptz default now(),
     updated_at timestamptz default now()
   );
   alter table designs enable row level security;
   create policy "owner full access" on designs
     for all using (auth.uid() = owner) with check (auth.uid() = owner);
   create policy "public read" on designs
     for select using (is_public = true);
   ```
4. **Storage layer**: add a `cloudStorage` module mirroring the local `storage.ts` API
   (list/get/create/update/rename/delete/duplicate) backed by the `designs` table. Make the
   store choose cloud when signed in, else local. Keep the same `StoredDesign` shape.
5. **Sharing**: a "Share" action sets `is_public = true` and produces a link like
   `/d/:id`; add a read-only viewer route that loads a public design by id and lets the
   visitor fork it into their own account.
6. **Validation**: cloud round-trip (save → reload → load) works; RLS prevents reading
   others' private designs; signed-out users still get full local mode.

---

## PHASE 6 — FREEMIUM & DESIGN CHALLENGES

Goal: free vs. Pro gating + gamified challenges.

1. **Plan model**: add a `profiles` table (or use Supabase user metadata) with `plan`
   (`free` | `pro`). A `usePlan()` hook exposes the current tier.
2. **Gating**: mark advanced components/chaos and large-graph limits as Pro. Show a lock
   icon and an "Upgrade" prompt when a free user hits a gated feature. Centralize limits in
   a `FEATURES`/`LIMITS` config (e.g. free: ≤ N nodes, basic chaos only, no AI).
3. **Billing (optional)**: integrate Stripe Checkout via a serverless endpoint + webhook
   that flips `plan` to `pro`. Keep keys server-side only.
4. **Challenges**: a `challenges` table `{ id, title, brief, targetQps, budget, constraints
   jsonb }`. A challenge runs the user's design through the engine and **scores** it from
   real metrics (e.g. "sustain 10k QPS at ≥99% success under $X"). Show pass/fail + score;
   award Pro trial for publishing a solution write-up.
5. **Validation**: gated features blocked for free; challenge scoring uses only engine output.

---

## PHASE 7 — AI LAYER (Pro)

Goal: (A) analyze a simulation and suggest fixes; (B) generate a design from a prompt.
**Never call the LLM from the browser.** All AI goes through a backend proxy.

1. **Backend proxy** (serverless function — Supabase Edge Function or Vercel function):
   - Requires auth; enforces **per-user quotas/rate limits**; uses a **cheap default model**;
     holds the LLM API key server-side; logs usage; caps output tokens.
2. **Feature A — Analyze**: client sends a **compact metrics summary** (per-node utilization,
   bottleneck, drops, p99, SPOF, success) — not the whole graph. Prompt: "identify the
   bottleneck and suggest 2–3 concrete fixes." Render suggestions in a panel.
3. **Feature B — Prompt-to-design**: LLM must return **strict JSON** `{ nodes, edges }`
   matching the canvas schema (use function-calling / JSON schema). **Validate** the output
   against `NODE_META`/edge rules before rendering (reject unknown kinds, dangling edges);
   retry/repair on invalid output. Then render and auto-run the simulation.
4. **Safety**: sanitize all LLM output; treat it as untrusted; never eval. Guard against
   prompt injection. Hard monthly budget alert on the provider.
5. **Validation**: malformed AI JSON is rejected gracefully; quotas enforced; analysis uses
   real metrics.

---

## DEPLOYMENT

- Frontend: build with `npm run build`; deploy `dist/` to Vercel or Cloudflare Pages
  (framework preset: Vite). Long-cache hashed `assets/*`, no-cache `index.html`.
- Phase 5+: Supabase hosts auth + Postgres; AI proxy as a serverless function with secrets
  in the platform's env (never in the client bundle).

## DELIVERABLES

Along with the app, produce: `README.md` (run instructions), `CLAUDE.md`/`AGENTS.md`
(project purpose + engine model + conventions for AI agents), `IMPLEMENTATION_PLAN.md`,
`TASKS.md`, and `DOCS.md` (architecture + the M/M/c & Erlang-C explanation with Mermaid
diagrams + deployment + future work). Keep `scripts/validate.ts` green and `npm run build`
passing at every phase.
