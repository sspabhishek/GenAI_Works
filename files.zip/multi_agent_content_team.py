"""
========================================================================
 MULTI-AGENT CONTENT TEAM  —  a small, real multi-agent app using Gemini
========================================================================

WHAT THIS DOES (the real task):
    Give it a topic, and a small "team" of AI agents will together
    produce a short, beginner-friendly article about it.

WHY MULTI-AGENT (the point you make to your trainer):
    Instead of ONE big AI doing everything, we use FOUR focused agents,
    each good at ONE job, plus a SUPERVISOR that coordinates them.

------------------------------------------------------------------------
 THE TEAM  (5 agents = 4 specialists + 1 supervisor)
------------------------------------------------------------------------
    1) Planner    -> turns the topic into a simple outline
    2) Researcher -> fills the outline with key facts / points
    3) Writer     -> writes the article from the outline + research
    4) Critic     -> reviews the draft and says APPROVE or REVISE
    5) Supervisor -> runs the team in order and decides when to STOP

------------------------------------------------------------------------
 HOW IT MAPS TO THE THEORY (say this while showing the code)
------------------------------------------------------------------------
    Shared memory  -> the `state` dictionary (every agent reads/writes it)
    Agents         -> the planner/researcher/writer/critic functions
    Handoff        -> the supervisor passing `state` from one agent to next
    Supervisor     -> the run_team() function (coordinates + decides)
    Stop condition -> Critic says APPROVE, OR we hit MAX_REVISIONS

------------------------------------------------------------------------
 FLOW DIAGRAM
------------------------------------------------------------------------
    topic
      |
      v
   [Planner] -> [Researcher] -> [Writer] --> [Critic]
                                   ^             |
                                   |   REVISE    |  (feedback)
                                   +-------------+
                                                 |  APPROVE
                                                 v
                                            final article
========================================================================
"""

# ----------------------------------------------------------------------
# STEP 0 — SETUP
# ----------------------------------------------------------------------
# We use Google's official "google-genai" SDK.
# Install it once with:   pip install google-genai
import os                                  # to read the API key from the environment
from google import genai                   # the Gemini SDK
from google.genai import types             # for extra settings (system prompt, temperature)

# Read the API key from an environment variable (safer than hard-coding it).
# Set it before running:
#   Mac/Linux :  export GEMINI_API_KEY="your_key_here"
#   Windows   :  set GEMINI_API_KEY=your_key_here
API_KEY = os.environ.get("GEMINI_API_KEY")

# Create ONE client that all agents will share to talk to Gemini.
client = genai.Client(api_key=API_KEY)

# The Gemini model every agent will use.
# gemini-2.5-flash is fast + cheap and great for a demo.
# (You can swap in a newer model like "gemini-3.6-flash" if your key has it.)
MODEL = "gemini-2.5-flash"

# Safety limit: how many times the Writer is allowed to revise the draft.
# This is our STOP CONDITION so the team never loops forever.
MAX_REVISIONS = 2


# ----------------------------------------------------------------------
# STEP 1 — ONE SHARED HELPER TO TALK TO GEMINI
# ----------------------------------------------------------------------
# Every agent is just "a focused prompt to Gemini". So we make ONE helper
# function here, and each agent will call it with its own instructions.
# This keeps the agents themselves tiny and easy to read.
def ask_gemini(role_instruction: str, task_prompt: str) -> str:
    """
    role_instruction : WHO the agent is (its job / personality) -> system prompt
    task_prompt       : WHAT we are asking it to do right now    -> user prompt
    returns           : Gemini's text answer
    """
    response = client.models.generate_content(
        model=MODEL,
        contents=task_prompt,                       # the actual request
        config=types.GenerateContentConfig(
            system_instruction=role_instruction,    # tells Gemini its role
            temperature=0.7,                         # 0 = strict, 1 = creative
        ),
    )
    return response.text.strip()


# ----------------------------------------------------------------------
# STEP 2 — THE 4 SPECIALIST AGENTS
# ----------------------------------------------------------------------
# NOTE: each agent takes the shared `state`, reads what it needs,
#       does its ONE job, and writes its result back into `state`.
#       That "read state -> do job -> write state" pattern is the
#       heart of every agent.

def planner_agent(state: dict) -> None:
    """AGENT 1 — makes a short outline from the topic."""
    print("Planner   : creating an outline...")
    role = "You are a Planner. You break a topic into a clear, simple outline."
    task = (
        f"Topic: {state['topic']}\n"
        "Give 3 short bullet points that a beginner article should cover. "
        "Only output the bullets."
    )
    state["outline"] = ask_gemini(role, task)     # HANDOFF: save outline into shared memory


def researcher_agent(state: dict) -> None:
    """AGENT 2 — adds key facts for each outline point."""
    print("Researcher: gathering key points...")
    role = "You are a Researcher. You provide accurate, simple facts for each outline point."
    task = (
        f"Topic: {state['topic']}\n"
        f"Outline:\n{state['outline']}\n\n"
        "For each bullet, write 1-2 simple factual sentences a beginner can understand."
    )
    state["research"] = ask_gemini(role, task)    # HANDOFF: save research into shared memory


def writer_agent(state: dict) -> None:
    """AGENT 3 — writes (or rewrites) the article draft."""
    print("Writer    : writing the draft...")
    role = "You are a Writer. You write short, friendly, easy-to-read articles."

    # If the Critic gave feedback earlier, include it so the Writer can improve.
    feedback_note = ""
    if state.get("feedback"):
        feedback_note = f"\nPlease improve the draft using this feedback:\n{state['feedback']}"

    task = (
        f"Topic: {state['topic']}\n"
        f"Outline:\n{state['outline']}\n\n"
        f"Facts:\n{state['research']}\n"
        f"{feedback_note}\n\n"
        "Write a beginner-friendly article of about 150 words."
    )
    state["draft"] = ask_gemini(role, task)       # HANDOFF: save draft into shared memory


def critic_agent(state: dict) -> None:
    """AGENT 4 — reviews the draft and decides APPROVE or REVISE."""
    print("Critic    : reviewing the draft...")
    role = (
        "You are a strict but fair Editor. Judge if an article is clear and complete. "
        "Reply with exactly 'APPROVE' if it is good enough. "
        "Otherwise reply 'REVISE:' followed by one short improvement."
    )
    task = f"Article:\n{state['draft']}"
    verdict = ask_gemini(role, task)

    # Read the verdict and update shared memory so the Supervisor can decide.
    if verdict.upper().startswith("APPROVE"):
        state["approved"] = True
        state["feedback"] = ""                    # no feedback needed
    else:
        state["approved"] = False
        # keep only the feedback part (after "REVISE:")
        state["feedback"] = verdict.split(":", 1)[-1].strip()


# ----------------------------------------------------------------------
# STEP 3 — THE SUPERVISOR (the coordinator + decision maker)
# ----------------------------------------------------------------------
# The supervisor does NOT write the article itself. Its only job is to
# run the specialists in the right order and decide when to stop.
def run_team(topic: str) -> str:
    """Runs the whole multi-agent team for one topic and returns the article."""

    # SHARED MEMORY: one dictionary that every agent reads from and writes to.
    state = {
        "topic": topic,
        "outline": "",
        "research": "",
        "draft": "",
        "feedback": "",
        "approved": False,
    }

    print(f"\nSupervisor: starting the team for topic -> '{topic}'\n")

    # 1) Plan, then research, then write the first draft. (fixed order)
    planner_agent(state)
    researcher_agent(state)
    writer_agent(state)

    # 2) Review loop: the Critic checks the draft.
    #    If it says REVISE, the Writer tries again — but only up to
    #    MAX_REVISIONS times, so we can never loop forever.
    for attempt in range(1, MAX_REVISIONS + 1):
        critic_agent(state)

        if state["approved"]:                      # STOP CONDITION #1
            print(f"Supervisor: approved on review #{attempt}. Done!\n")
            break

        print(f"Supervisor: not approved -> asking Writer to revise (round {attempt})\n")
        writer_agent(state)                        # Writer rewrites using feedback
    else:
        # This runs if the loop finished WITHOUT a break (STOP CONDITION #2)
        print("Supervisor: reached the revision limit. Using the latest draft.\n")

    # 3) The final draft in shared memory is our answer.
    return state["draft"]


# ----------------------------------------------------------------------
# STEP 4 — RUN IT
# ----------------------------------------------------------------------
# This block only runs when you execute the file directly.
if __name__ == "__main__":
    # Friendly check so the demo fails clearly if the key is missing.
    if not API_KEY:
        raise SystemExit("Please set your GEMINI_API_KEY environment variable first.")

    # The real task input. Change this to any topic you like.
    topic = "How do solar panels work?"

    # Hand the topic to the supervisor and get the finished article back.
    article = run_team(topic)

    # Show the result.
    print("=" * 60)
    print("FINAL ARTICLE")
    print("=" * 60)
    print(article)
