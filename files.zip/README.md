# Multi-Agent Content Team (Gemini)

A tiny, real multi-agent app. Give it a topic, and a small team of AI agents
writes a short, beginner-friendly article about it — using **Google Gemini**.

Plain Python, **no framework**, comments everywhere — so you can explain every line.

---

## The team (5 agents = 4 specialists + 1 supervisor)

| Agent | Job |
|-------|-----|
| Planner | Turns the topic into a 3-point outline |
| Researcher | Adds simple key facts for each point |
| Writer | Writes (and rewrites) the article |
| Critic | Reviews the draft: **APPROVE** or **REVISE** |
| Supervisor | Runs the team in order and decides when to **stop** |

**Flow:** `topic → Planner → Researcher → Writer → Critic → (revise loop) → final article`

---

## How to run

1. Get a free Gemini API key from Google AI Studio.

2. Install the SDK:
   ```bash
   pip install -r requirements.txt
   ```

3. Set your key:
   ```bash
   # Mac / Linux
   export GEMINI_API_KEY="your_key_here"
   # Windows
   set GEMINI_API_KEY=your_key_here
   ```

4. Run it:
   ```bash
   python multi_agent_content_team.py
   ```

You'll see each agent print what it's doing, then the final article. Change the
`topic` variable at the bottom of the file to try any subject.

---

## How to present it (talking points)

Walk your trainer through it in this order:

1. **The idea** — "Instead of one AI doing everything, I use four focused agents
   plus a supervisor that coordinates them."

2. **Shared memory** — point at the `state` dictionary: "Every agent reads from
   and writes to this one shared notebook. That's how one agent's work becomes
   the next agent's input."

3. **An agent** — open `writer_agent`: "Each agent is just: read the state, send
   a focused prompt to Gemini, save the result back. That last save is the *handoff*."

4. **The supervisor** — open `run_team`: "It doesn't write anything itself. It
   runs the specialists in order, then loops the Critic and Writer until the
   Critic approves — or we hit the revision limit."

5. **The stop condition** — point at `MAX_REVISIONS`: "This stops it from looping
   forever — a must-have in any multi-agent system."

6. **Why this design** — "Focused agents = clearer prompts and better output. The
   supervisor keeps it simple to follow and easy to debug."

**One line to remember:** *"Shared memory carries the information; the supervisor
decides whose turn it is and when to stop."*
